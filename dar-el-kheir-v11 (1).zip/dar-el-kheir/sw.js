/* Dar El Kheir service worker: shows notifications and lets one tap open the app. */
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
self.addEventListener('notificationclick', e => {
  e.notification.close();
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(l => {
    if (l.length) return l[0].focus();
    return self.clients.openWindow('/');
  }));
});
