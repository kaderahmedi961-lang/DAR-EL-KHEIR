
(function(){
'use strict';
/* ---------- constants ---------- */
const PAGE=['admin','manage','topups'].includes(document.body.dataset.page)?document.body.dataset.page:'site';
const ISPANEL=PAGE!=='site';
const WA_DEFAULT='22230473900';
const BLOOD=['A+','A-','B+','B-','AB+','AB-','O+','O-'];
const WILAYAS=[['الحوض الشرقي','Hodh Ech Chargui'],['الحوض الغربي','Hodh El Gharbi'],['لعصابة','Assaba'],['كوركول','Gorgol'],['لبراكنة','Brakna'],['الترارزة','Trarza'],['آدرار','Adrar'],['داخلت نواذيبو','Dakhlet Nouadhibou'],['تكانت','Tagant'],['كيدي ماغا','Guidimaka'],['تيرس زمور','Tiris Zemmour'],['إنشيري','Inchiri'],['نواكشوط الغربية','Nouakchott Ouest'],['نواكشوط الشمالية','Nouakchott Nord'],['نواكشوط الجنوبية','Nouakchott Sud']];
const wname=i=>{const w=WILAYAS[Number(i)];return w?(S.lang==='ar'?w[0]:w[1]):''};
const CATS=['urgent','active','review','water','ramadan'];
const METHODS=['bankily','masrvi','sedad'];

/* ---------- translations ---------- */
const L=[
['appName','دار الخير','Dar El Kheir'],
['tagline','طريقك إلى الخير، بشفافية وأمان','Your path to giving, with transparency and trust'],
['login_title','تسجيل الدخول','Sign in'],
['login_sub','أدخل رقم حسابك (رقم هاتفك) وكلمة السر.','Enter your account number (your phone number) and your password.'],
['acc_label','رقم الحساب','Account number'],
['acc_ph','مثال: 12345678','e.g. 12345678'],
['code_label','كلمة السر','Password'],
['verify_btn','دخول','Sign in'],
['checking','جارٍ التحقق…','Checking…'],
['show','إظهار','Show'],
['err_acc','أدخل رقم حساب صحيحاً (4 إلى 20 حرفاً أو رقماً).','Enter a valid account number (4 to 20 letters or digits).'],
['err_code','كلمة السر من 4 أحرف على الأقل.','Password must be at least 4 characters.'],
['err_wrong','رقم الحساب أو الرمز غير صحيح.','Wrong account number or code.'],
['err_suspended','هذا الحساب موقوف. تواصل مع الإدارة.','This account is suspended. Contact the administration.'],
['err_generic','تعذّر إكمال العملية. حاول مرة أخرى.','Something went wrong. Please try again.'],
['err_amount','أدخل مبلغاً صحيحاً.','Enter a valid amount.'],
['err_insufficient','رصيدك لا يكفي لهذا المبلغ.','Your balance is not enough for this amount.'],
['err_ref','أدخل رقم العملية كما ظهر في تطبيق الدفع.','Enter the transaction reference shown in your payment app.'],
['err_phone','أدخل رقماً من 8 أرقام.','Enter an 8-digit phone number.'],
['err_name','أدخل الاسم.','Enter the name.'],
['err_noacc','هذا الحساب غير موجود بين الحسابات الموثقة.','This account is not among the verified accounts.'],
['err_title','أدخل عنواناً بالعربية أو الإنجليزية.','Enter a title in Arabic or English.'],
['err_goal','أدخل المبلغ المطلوب.','Enter the goal amount.'],
['dbOff_title','الموقع غير متاح الآن','The site is unavailable right now'],
['dbOff_text','تعذّر الاتصال بالخادم. تحقق من الاتصال ثم أعد تحميل الصفحة.','Could not reach the server. Check your connection and reload the page.'],
['terms','بمتابعتك فأنت توافق على شروط الاستخدام وسياسة الخصوصية','By continuing you agree to the terms of use and privacy policy'],
['suspended_title','الحساب موقوف','Account suspended'],
['switch_acc','استخدام حساب آخر','Use another account'],
['verified_now','تم توثيق حسابك، مرحباً بك.','Your account is verified. Welcome.'],
['st_pending','قيد المراجعة','Under review'],
['st_verified','موثّق','Verified'],
['st_rejected','مرفوض','Rejected'],
['st_suspended','موقوف','Suspended'],
['st_approved','مقبول','Approved'],
['salaam','السلام عليكم','Peace be upon you'],
['wallet_balance','رصيد المحفظة','Wallet balance'],
['wallet_hint','اشحن محفظتك لتتمكن من التبرع للحالات الموثقة','Top up your wallet to donate to verified cases'],
['topup_btn','شحن الرصيد','Top up'],
['topup_methods','طرق الشحن','Top-up methods'],
['sections','أقسام الموقع','Sections'],
['latest','أحدث الحالات','Latest cases'],
['cat_all','الكل','All'],
['cat_urgent','الحالات الطارئة','Urgent cases'],
['cat_active','الحالات الموجودة','Open cases'],
['cat_review','حالات تحت المراجعة','Cases under review'],
['cat_water','سقيا الماء','Water for all'],
['cat_ramadan','المبادرات الرمضانية','Ramadan initiatives'],
['new_acc','إنشاء حساب جديد','Create a new account'],['have_acc','لدي حساب بالفعل','I already have an account'],
['reg_title','إنشاء حساب','Create account'],['reg_sub','املأ بياناتك ثم أرسلها. يمكنك تجربة التطبيق مجاناً بينما يتم توثيق حسابك عبر واتساب.','Fill in your details and send them. You can try the app for free while your account is verified via WhatsApp.'],
['first_name','الاسم الأول','First name'],['last_name','اللقب','Last name'],['nid','الرقم الوطني','National ID number'],['pw_label','كلمة السر','Password'],['pw2_label','تأكيد كلمة السر','Confirm password'],['send_info','إرسال المعلومات','Send information'],
['err_first','أدخل الاسم الأول واللقب.','Enter your first and last name.'],['err_nid','أدخل رقماً وطنياً صحيحاً (من 8 إلى 14 رقماً).','Enter a valid national ID number (8 to 14 digits).'],
['err_pwlen','كلمة السر من 6 إلى 64 حرفاً.','Password must be 6 to 64 characters.'],['err_pwmatch','تأكيد كلمة السر غير مطابق.','The password confirmation does not match.'],
['err_exists','هذا الرقم مسجّل بالفعل. سجّل الدخول.','This number is already registered. Please sign in.'],['err_exists_nid','هذا الرقم الوطني مسجّل بالفعل.','This national ID is already registered.'],
['err_unverified','يجب توثيق حسابك أولاً.','Your account must be verified first.'],['rejected_title','تم رفض التوثيق','Verification rejected'],['err_rejected','تم رفض توثيق حسابك. تواصل مع الإدارة.','Your verification was rejected. Please contact the administration.'],
['trial_title','تجربة مجانية','Free trial'],['trial_note','حسابك قيد التوثيق. يمكنك تصفح التطبيق، لكن لا يمكنك التبرع أو شحن رصيدك قبل توثيق الحساب.','Your account is being verified. You can browse the app, but you cannot donate or top up until it is verified.'],
['trial_block','هذه العملية متاحة بعد توثيق حسابك فقط.','This action is available after your account is verified.'],['trial_wa','إرسال طلب التوثيق عبر واتساب','Send verification request on WhatsApp'],
['notif_title','فعّل الإشعارات للمتابعة','Turn on notifications to continue'],['notif_text','التطبيق لا يعمل بدون الإشعارات. سنخبرك بتوثيق حسابك، وقبول الشحن، والحالات الجديدة.','The app does not work without notifications. We will tell you about verification, top-ups and new cases.'],
['notif_btn','تفعيل الإشعارات','Enable notifications'],['notif_denied','الإشعارات محظورة. افتح إعدادات المتصفح للموقع، واسمح بالإشعارات، ثم اضغط «تحقق مرة أخرى».','Notifications are blocked. Open the site settings in your browser, allow notifications, then tap “Check again”.'],
['notif_recheck','تحقق مرة أخرى','Check again'],['notif_unsupported','هذا المتصفح لا يدعم الإشعارات. على الآيفون: افتح الموقع في Safari، اضغط مشاركة ثم «إضافة إلى الشاشة الرئيسية»، وافتحه من هناك.','This browser does not support notifications. On iPhone: open the site in Safari, tap Share, then “Add to Home Screen”, and open it from there.'],
['n_new_case','حالة جديدة','New case'],['n_top_ok','تم قبول شحن رصيدك','Your top-up was approved'],['n_top_no','تم رفض طلب الشحن','Your top-up was rejected'],
['pend_acc','طلبات توثيق الحسابات','Account verification requests'],['s_wa','رقم واتساب الإدارة (للتوثيق)','Admin WhatsApp number (verification)'],
['tab_reports','التقارير','Reports'],['r_day','التقرير اليومي','Daily report'],['r_month','التقرير الشهري','Monthly report'],['r_pick_day','اليوم','Day'],['r_pick_month','الشهر','Month'],
['r_new_acc','حسابات جديدة','New accounts'],['r_verified','حسابات تم توثيقها','Accounts verified'],['r_logins','عمليات الدخول','Sign-ins'],['r_active','مستخدمون نشطون','Active users'],
['r_top_req','طلبات الشحن','Top-up requests'],['r_top_ok','شحن مقبول (MRU)','Approved top-ups (MRU)'],['r_manual','إضافات الإدارة (MRU)','Admin credits (MRU)'],
['r_don_n','عدد التبرعات','Donations count'],['r_don_amt','مبلغ التبرعات (MRU)','Donations amount (MRU)'],['r_don_cases','منها للحالات (MRU)','To cases (MRU)'],['r_don_ch','منها للجمعية (MRU)','To charity (MRU)'],
['r_donors','طلبات متبرعين بالدم','Blood donor requests'],['r_by_day','التفصيل اليومي','Day by day'],['r_top_cases','أكثر الحالات تبرعاً','Top cases'],['r_day_col','اليوم','Day'],['r_none','لا توجد بيانات في هذه الفترة.','No data in this period.'],
['err_locked','محاولات كثيرة خاطئة. حاول بعد 15 دقيقة.','Too many wrong attempts. Try again in 15 minutes.'],
['err_taken','رقم الحساب هذا مستخدم سابقاً. اختر رقماً آخر.','This account number was used before. Choose another.'],
['err_dup_ref','رقم العملية هذا مُرسل من قبل.','This transaction reference was already submitted.'],
['case_secret','الرمز السري للحالة (للسحب)','Case secret code (for withdrawals)'],['secret_hint','اتركه فارغاً للإبقاء على الرمز الحالي','Leave empty to keep the current code'],
['case_acct','حساب الحالة','Case account'],['acct_raised','إجمالي أموال الحالة','Total case funds'],['acct_withdrawn','المسحوب','Withdrawn'],['acct_avail','المتاح','Available'],['acct_donors','تبرعات الحالة','Case donations'],
['wd_title','سحب أموال','Withdraw funds'],['wd_amount','المبلغ المسحوب (MRU)','Amount to withdraw (MRU)'],['wd_payee','اسم المستلم','Recipient name'],['wd_purpose','سبب السحب','Reason for withdrawal'],['wd_secret','الرمز السري للحالة','Case secret code'],['wd_btn','سحب وإصدار الفاتورة','Withdraw and issue invoice'],['wd_list','عمليات السحب','Withdrawals'],
['inv_title','فاتورة سحب أموال','Funds Withdrawal Invoice'],['inv_no','رقم الفاتورة','Invoice no.'],['inv_case','الحالة','Case'],['inv_payee','المستلم','Recipient'],['inv_purpose','السبب','Reason'],['inv_date','التاريخ','Date'],['inv_manager','المدير','Manager'],['inv_signed','موقّعة ومعتمدة','Signed and approved'],['view_invoice','الفاتورة','Invoice'],['case_report','تقرير الحالة','Case report'],
['err_secret','الرمز السري غير صحيح.','Wrong secret code.'],['err_nosecret','لا يوجد رمز سري لهذه الحالة. عدّل الحالة وضع رمزاً.','This case has no secret code. Edit the case and set one.'],['err_wd_over','المبلغ أكبر من المتاح في حساب الحالة.','The amount is more than the case account balance.'],['err_secret_len','الرمز السري للحالة من 4 إلى 12 خانة.','The case secret code must be 4 to 12 characters.'],['act_withdraw','سحب أموال','Funds withdrawal'],
['r_wd','المسحوب من الحالات','Withdrawn from cases'],
['err_receipt','صورة الإيصال إجبارية. أرفق صورة الإيصال.','The receipt photo is required. Please attach it.'],
['do_donate','تبرع','Donate'],['donate_to','التبرع إلى','Donate to'],['profile','الملف الشخصي','Profile'],['nick','الاسم أو اللقب','Name or nickname'],['photo_pick','اختر صورة','Choose photo'],['photo_rm','إزالة الصورة','Remove photo'],['saved','تم الحفظ','Saved'],['statement','كشف الحساب','Account statement'],['st_in','إجمالي الإيداعات','Total deposits'],['st_out','إجمالي التبرعات','Total donations'],['print','طباعة','Print'],['blood_place','مكان التبرع بالدم','Blood donation location'],['blood_noplace','سيتم تحديد مكان التبرع قريباً.','The donation location will be announced soon.'],['s_blood_ar','مكان التبرع بالدم (عربي)','Blood donation location (Arabic)'],['s_blood_en','مكان التبرع بالدم (إنجليزي)','Blood donation location (English)'],['act_profile_saved','تحديث الملف الشخصي','Profile updated'],
['blood','بنك الدم','Blood bank'],
['bs_title','البحث عن متبرع بالدم','Find a blood donor'],['bs_note','أدخل المستشفى وفصيلة الدم والولاية، ويتولى فريق دار الخير البحث عن متبرع ويتواصل معك.','Enter the hospital, blood type and wilaya, and the Dar El Kheir team will look for a donor and contact you.'],['bs_hospital','المستشفى الموجود فيه المريض','Hospital where the patient is'],['bs_wilaya','الولاية','Wilaya'],['bs_send','إرسال طلب البحث','Send search request'],['bs_sent','تم إرسال طلبك. سيتولى الفريق البحث عن متبرع.','Request sent. The team will look for a donor.'],['bs_mine','طلباتي السابقة','My previous requests'],['bs_open','قيد البحث','Searching'],['bs_found','تم إيجاد متبرع','Donor found'],['bs_closed','مغلق','Closed'],['err_hospital','أدخل اسم المستشفى.','Enter the hospital name.'],['tab_blood','طلبات الدم','Blood requests'],['bs_reqs','طلبات البحث عن متبرع','Donor search requests'],['bs_none','لا توجد طلبات.','No requests.'],['bs_set_open','قيد البحث','Searching'],['bs_set_found','تم إيجاد متبرع','Donor found'],['bs_set_closed','إغلاق','Close'],['bs_contact','رقم صاحب الطلب','Requester number'],['act_blood_search','طلب البحث عن متبرع','Donor search request'],['act_blood_search_open','إعادة فتح طلب دم','Blood request reopened'],['act_blood_search_found','تم إيجاد متبرع','Donor found'],['act_blood_search_closed','إغلاق طلب دم','Blood request closed'],
['charities','الجمعيات الخيرية','Charities'],
['nav_home','الرئيسية','Home'],
['nav_cases','الحالات','Cases'],
['nav_wallet','المحفظة','Wallet'],
['nav_account','حسابي','Account'],
['back','رجوع','Back'],
['verified_badge','موثقة','Verified'],
['donors_n','متبرع','donors'],
['days_n','{n} أيام متبقية','{n} days left'],
['days_label','أيام متبقية','days left'],
['raised','تم جمع','Raised'],
['goal','المطلوب','Goal'],
['funded','مكتمل','funded'],
['remaining','متبقي','remaining'],
['story','قصة الحالة','Case story'],
['donate_btn','التبرع من رصيدي','Donate from my balance'],
['need_topup','عذراً، يجب شحن محفظتك أولاً','Sorry, you need to top up your wallet first'],
['your_balance','رصيدك الحالي {n} MRU','Your balance is {n} MRU'],
['topup_now','شحن المحفظة الآن','Top up wallet now'],
['donate_amount','مبلغ التبرع (MRU)','Donation amount (MRU)'],
['donated_ok','جزاك الله خيراً، تم التبرع.','Thank you, your donation was sent.'],
['review_note','هذه الحالة قيد المراجعة ولا تقبل التبرعات حالياً.','This case is under review and is not accepting donations yet.'],
['closed_note','انتهت مدة هذه الحالة أو اكتمل مبلغها.','This case has ended or reached its goal.'],
['no_cases','لا توجد حالات في هذا القسم حالياً.','There are no cases in this section yet.'],
['topup_title','طلب شحن الرصيد','Top-up request'],
['topup_how','حوّل المبلغ من تطبيق الدفع ثم أرسل رقم العملية هنا. تُضاف القيمة إلى محفظتك بعد مراجعة الإدارة.','Send the money from your payment app, then enter the transaction reference here. The amount is added to your wallet after the administration reviews it.'],
['pay_method','وسيلة الدفع','Payment method'],
['pay_to','حوّل المبلغ إلى الرقم','Send the payment to'],
['not_set','لم يحدد بعد','Not set yet'],
['m_bankily','بنكيلي','Bankily'],
['m_masrvi','مصرفي','Masrvi'],
['m_sedad','سداد','Sedad'],
['m_cash','نقداً','Cash'],
['m_other','أخرى','Other'],
['amount','المبلغ (MRU)','Amount (MRU)'],
['tx_ref','رقم العملية','Transaction reference'],
['receipt','صورة الإيصال (إجباري)','Receipt photo (required)'],
['send_req','إرسال الطلب','Send request'],
['topup_sent','تم إرسال طلب الشحن. تُضاف القيمة بعد مراجعة الإدارة.','Top-up request sent. The amount is added after review.'],
['history','سجل العمليات','Transaction history'],
['no_history','لا توجد عمليات بعد.','No transactions yet.'],
['tx_topup','شحن رصيد','Top-up'],
['tx_donation','تبرع','Donation'],
['tx_adjust','تعديل من الإدارة','Administration adjustment'],
['blood_notice','جميع المتبرعين تم التحقق منهم من قبل الإدارة','All donors are verified by the administration'],
['blood_search','ابحث بالمدينة أو فصيلة الدم','Search by city or blood type'],
['register_donor','التبرع بالدم','Donate blood'],
['appears_after','أدخل بياناتك ليتم تسجيلك كمتبرع بالدم','Enter your details to be registered as a blood donor'],
['donor_review','جاري تسجيلك كمتبرع بالدم','Registering you as a blood donor…'],
['donor_you','أنت مسجّل كمتبرع بالدم','You are registered as a blood donor'],
['by_admin','موثّق من الإدارة','Verified by admin'],
['show_number','إظهار الرقم','Show number'],
['call','اتصال','Call'],
['full_name','الاسم الكامل','Full name'],
['blood_type','فصيلة الدم','Blood type'],
['city','المدينة','City'],
['phone','رقم الهاتف (8 أرقام)','Phone number (8 digits)'],
['donor_sent','تم إرسال طلبك. يظهر اسمك بعد التوثيق.','Request sent. You appear once verified.'],
['no_donors','لا يوجد متبرعون موثقون لهذا البحث.','No verified donors match this search.'],
['ch_title','جمعيات معتمدة من الإدارة','Charities approved by the administration'],
['ch_sub','نعمل معها لإيصال الخير إلى مستحقيه بشفافية','We work with them to deliver help to those in need, transparently'],
['ch_search','ابحث عن جمعية','Search charities'],
['no_ch','لا توجد جمعيات مطابقة.','No matching charities.'],
['account','حسابي','My account'],
['status','الحالة','Status'],
['language','اللغة','Language'],
['logout','تسجيل الخروج','Sign out'],
['admin_panel','لوحة التحكم','Control panel'],['panel_manage','لوحة الحالات والجمعيات والسحب','Cases, charities and withdrawals panel'],['panel_topups','لوحة شحن الأموال','Wallet top-up panel'],['tab_security','كلمة المرور','Password'],['phone_login','رقم الهاتف','Phone number'],['phone_ph','30473900','30473900'],['abroad_q','خارج الوطن؟','Outside the country?'],['abroad_txt','تواصل معنا عبر واتساب لتوثيق حسابك.','Contact us on WhatsApp to verify your account.'],['abroad_btn','تواصل عبر واتساب','Contact on WhatsApp'],['create_acc','إنشاء حساب (للمقيمين خارج الوطن)','Create account (for people abroad)'],['create_acc_hint','اكتب الرقم بالصيغة الدولية بدون +، مثال: 33612345678','Write the number in international format without +, e.g. 33612345678'],['do_create','إنشاء الحساب','Create account'],['act_account_created','إنشاء حساب بواسطة الإدارة','Account created by admin'],
['cancel','إلغاء','Cancel'],
['save','حفظ','Save'],
['delete','حذف','Delete'],
['edit','تعديل','Edit'],
['confirm','تأكيد','Confirm'],
['done','تم.','Done.'],
['saved','تم الحفظ.','Saved.'],
['err_over','المبلغ أكبر من المتبقي لهذه الحالة.','The amount is more than what this case still needs.'],
['err_rate','محاولات كثيرة. انتظر بضع دقائق ثم حاول مرة أخرى.','Too many attempts. Wait a few minutes and try again.'],
['err_image','تعذّر قبول الصورة. اختر صورة JPG أو PNG أو WebP أصغر حجماً.','The image was not accepted. Choose a smaller JPG, PNG or WebP image.'],
['err_pw','كلمة المرور الجديدة يجب ألا تقل عن 8 أحرف وأن تطابق التأكيد.','The new password must be at least 8 characters and match the confirmation.'],
['err_pw_wrong','كلمة المرور غير صحيحة.','Wrong password.'],
['admin_login_title','دخول الإدارة','Administrator sign in'],
['admin_login_sub','أدخل كلمة مرور لوحة التحكم.','Enter the control panel password.'],
['admin_pw','كلمة المرور','Password'],
['sign_in','دخول','Sign in'],
['admin_logout','خروج الإدارة','Admin sign out'],
['pw_title','تغيير كلمة مرور الإدارة','Change the admin password'],
['pw_cur','كلمة المرور الحالية','Current password'],
['pw_new','كلمة المرور الجديدة','New password'],
['pw_again','تأكيد كلمة المرور الجديدة','Confirm new password'],
['act_phone_view','عرض رقم متبرع','Viewed a donor number'],
['act_case_saved','حفظ حالة','Case saved'],
['act_item_deleted','حذف عنصر','Item deleted'],
['act_settings_saved','حفظ الإعدادات','Settings saved'],
['act_password_changed','تغيير كلمة مرور الإدارة','Admin password changed'],
['act_register','إنشاء حساب','Account created'],
['close','إغلاق','Close'],
/* admin */
['no_access','هذه الصفحة للإدارة فقط.','This page is for administrators only.'],
['back_site','العودة إلى الموقع','Back to the site'],
['tab_overview','نظرة عامة','Overview'],
['tab_accounts','الحسابات','Accounts'],
['tab_tx','المعاملات','Transactions'],
['tab_cases','الحالات','Cases'],
['tab_donors','المتبرعون بالدم','Blood donors'],
['tab_charities','الجمعيات','Charities'],
['tab_activity','النشاط','Activity'],
['tab_settings','الإعدادات','Settings'],
['s_pending_acc','حسابات تنتظر التوثيق','Accounts awaiting verification'],
['s_pending_top','طلبات شحن معلّقة','Pending top-ups'],
['s_pending_don','متبرعون ينتظرون التوثيق','Donors awaiting verification'],
['s_accounts','حسابات موثقة','Verified accounts'],
['s_credit','إجمالي الشحن (MRU)','Total credited (MRU)'],
['s_donated','إجمالي التبرعات (MRU)','Total donated (MRU)'],
['s_cases','الحالات المنشورة','Published cases'],
['s_donors','متبرعون موثقون','Verified donors'],
['recent','آخر النشاط','Recent activity'],
['all_acc','كل الحسابات','All accounts'],
['approve','قبول','Approve'],
['reject','رفض','Reject'],
['suspend','إيقاف','Suspend'],
['reactivate','إعادة تفعيل','Reactivate'],
['acc_name','اسم الحساب','Account name'],
['balance','الرصيد','Balance'],
['created','التاريخ','Date'],
['search_acc','بحث برقم الحساب أو الاسم','Search by account number or name'],
['none_pending','لا توجد طلبات معلّقة.','No pending requests.'],
['topup_reqs','طلبات الشحن','Top-up requests'],
['upload_tx','رفع معاملة','Upload a transaction'],
['tx_note','أضف مبلغاً إلى محفظة مستخدم (أو اطرح بإشارة سالبة) مع صورة الإيصال.','Add an amount to a user wallet (or deduct with a negative sign) with the receipt image.'],
['account_no','رقم الحساب','Account number'],
['note','ملاحظة','Note'],
['image','صورة','Image'],
['choose_img','اختر صورة','Choose image'],
['ledger','سجل المعاملات','Transactions ledger'],
['method','الوسيلة','Method'],
['source_admin','الإدارة','Administration'],
['source_topup','طلب شحن','Top-up request'],
['new_case','حالة جديدة','New case'],
['edit_case','تعديل الحالة','Edit case'],
['title_ar','العنوان بالعربية','Title (Arabic)'],
['title_en','العنوان بالإنجليزية','Title (English)'],
['loc_ar','المكان بالعربية','Place (Arabic)'],
['loc_en','المكان بالإنجليزية','Place (English)'],
['story_ar','القصة بالعربية','Story (Arabic)'],
['story_en','القصة بالإنجليزية','Story (English)'],
['goal_amt','المبلغ المطلوب (MRU)','Goal amount (MRU)'],
['base_raised','مبلغ مجموع سابقاً (MRU)','Already raised (MRU)'],
['base_donors','متبرعون سابقون','Earlier donors'],
['deadline','آخر موعد','Deadline'],
['category','القسم','Section'],
['donations','تبرعات','donations'],
['donor_reqs','طلبات التسجيل كمتبرع','Donor registration requests'],
['all_donors','المتبرعون الموثقون','Verified donors'],
['add_donor','إضافة متبرع','Add donor'],
['edit_donor','تعديل المتبرع','Edit donor'],
['new_charity','جمعية جديدة','New charity'],
['edit_charity','تعديل الجمعية','Edit charity'],
['ch_name_ar','الاسم بالعربية','Name (Arabic)'],
['ch_name_en','الاسم بالإنجليزية','Name (English)'],
['ch_desc_ar','الوصف بالعربية','Description (Arabic)'],
['ch_desc_en','الوصف بالإنجليزية','Description (English)'],
['icon','الأيقونة','Icon'],
['i_heart','قلب','Heart'],
['i_building','مبنى','Building'],
['i_water','ماء','Water'],
['i_drop','دم','Blood'],
['user_activity','نشاط المستخدمين','User activity'],
['filter_acc','تصفية برقم الحساب','Filter by account number'],
['when','الوقت','Time'],
['action','الإجراء','Action'],
['detail','التفاصيل','Details'],
['prune','حذف السجلات القديمة','Delete old entries'],
['pruned','تم حذف السجلات القديمة.','Old entries deleted.'],
['act_login','تسجيل دخول','Signed in'],
['act_register_request','طلب توثيق حساب','Verification request'],
['act_account_verified','توثيق حساب','Account verified'],
['act_account_rejected','رفض توثيق','Verification rejected'],
['act_account_suspended','إيقاف حساب','Account suspended'],
['act_account_reactivated','إعادة تفعيل حساب','Account reactivated'],
['act_account_deleted','حذف حساب','Account deleted'],
['act_topup_request','طلب شحن','Top-up request'],
['act_topup_approved','قبول شحن','Top-up approved'],
['act_topup_rejected','رفض شحن','Top-up rejected'],
['act_tx_upload','رفع معاملة','Transaction uploaded'],
['act_donation','تبرع','Donation'],
['act_donor_request','طلب تسجيل متبرع','Donor request'],
['act_donor_approved','توثيق متبرع','Donor verified'],
['act_donor_rejected','رفض متبرع','Donor rejected'],
['settings_title','إعدادات الموقع','Site settings'],
['pay_numbers','أرقام استلام الشحن','Numbers that receive top-ups'],
['sure','هل أنت متأكد؟ لا يمكن التراجع عن هذا الإجراء.','Are you sure? This cannot be undone.'],
['receipt_view','عرض الإيصال','View receipt'],
['no_receipt','بلا إيصال','No receipt']
];
const T={ar:{},en:{}};L.forEach(([k,a,e])=>{T.ar[k]=a;T.en[k]=e});

/* ---------- state ---------- */
const S={lang:'ar',view:'home',caseId:null,casesFilter:'all',bloodFilter:'all',q:'',chq:'',
 dbChecked:false,offline:false,me:null,isAdmin:false,cred:null,accountDoc:null,requestDoc:null,myDonorReq:null,accLoaded:false,
 loaded:{acc:false,req:false},codePlain:'',showCode:false,err:'',busy:false,f:{},modal:null,toast:'',revealed:{},
 adminTab:PAGE==='manage'?'cases':PAGE==='topups'?'tx':'overview',adminQ:'',
 D:{cases:[],charities:[],donors:[],settings:[],donations:[],accounts:[],ledger:[],requests:[],donor_requests:[],topups:[],activity:[],myLedger:[],myTopups:[],withdrawals:[]}};
const unsubs={base:[],user:[],admin:[]};
const ls={get(k){try{return localStorage.getItem(k)}catch(e){return null}},set(k,v){try{localStorage.setItem(k,v)}catch(e){}},del(k){try{localStorage.removeItem(k)}catch(e){}}};

/* ---------- helpers ---------- */
const root=document.getElementById('app');
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const t=(k,v)=>String((T[S.lang][k]!=null?T[S.lang][k]:(T.ar[k]!=null?T.ar[k]:k))).replace(/\{(\w+)\}/g,(m,n)=>v&&v[n]!=null?v[n]:m);
const loc=o=>typeof o==='string'?o:((o&&(o[S.lang]||o.ar||o.en))||'');
const now=()=>new Date().toISOString();
const digits=s=>String(s==null?'':s).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
const num=s=>{const n=Number(digits(s).replace(/[^\d.\-]/g,''));return isFinite(n)?n:0};
const fmt=n=>new Intl.NumberFormat('en-US').format(Math.round(Number(n)||0));
const fmtDate=iso=>{if(!iso)return '';try{return new Intl.DateTimeFormat(S.lang==='ar'?'ar-u-nu-latn':'en-GB',{dateStyle:'medium',timeStyle:'short'}).format(new Date(iso))}catch(e){return iso}};
const gp=(o,p)=>p.split('.').reduce((a,k)=>a==null?a:a[k],o);
const sp=(o,p,v)=>{const ks=p.split('.');let a=o;ks.slice(0,-1).forEach(k=>{if(a[k]==null||typeof a[k]!=='object')a[k]={};a=a[k]});a[ks[ks.length-1]]=v};
let raf=0;const sched=()=>{cancelAnimationFrame(raf);raf=requestAnimationFrame(render)};
let tt=0;const toast=m=>{S.toast=m;sched();clearTimeout(tt);tt=setTimeout(()=>{S.toast='';sched()},3400)};
const payNum=m=>{const s=S.D.settings.find(x=>x.id==='main');return (s&&s[m])||''};
const imgSrc=d=>d?(d.image||d.receipt||''):'';
const sum=(a,f)=>a.reduce((s,x)=>s+(Number(f(x))||0),0);
const balanceOf=(acc,ledger,don)=>sum(ledger.filter(x=>x.accountNo===acc),x=>x.amount)-sum(don.filter(x=>x.accountNo===acc),x=>x.amount);
const myBalance=()=>S.cred?balanceOf(S.cred.acc,S.D.myLedger,S.D.donations):0;
const accSt=()=>S.accountDoc&&S.accountDoc.status;
const isLoggedIn=()=>!!(S.cred&&(accSt()==='verified'||accSt()==='pending'));
const isVerified=()=>!!(S.cred&&accSt()==='verified');

/* ---------- icons ---------- */
const P={
home:'M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10',list:'M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01',
wallet:'M20 8V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-2M21 12h-4a2 2 0 0 0 0 4h4v-4z',
user:'M12 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM4 21c0-4 3.5-6 8-6s8 2 8 6',
shield:'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3zM8.5 12l2.5 2.5 4.5-5',check:'M5 12.5l4.5 4.5L19 7.5',
phone:'M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A15 15 0 0 1 3 6a2 2 0 0 1 2-2z',
pin:'M12 21s7-6 7-11a7 7 0 0 0-14 0c0 5 7 11 7 11zM12 7.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5z',
moon:'M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5z',
drop:'M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11zM12 11v6M9 14h6',
water:'M12 3s5 5.5 5 9.5a5 5 0 0 1-10 0C7 8.5 12 3 12 3zM3 20c1.5-1.2 3-1.2 4.5 0s3 1.2 4.5 0 3-1.2 4.5 0 3 1.2 4.5 0',
building:'M4 21V8l8-5 8 5v13M9 21v-6h6v6M8 11h.01M12 11h.01M16 11h.01',
heart:'M12 20s-8-5-8-11a4.5 4.5 0 0 1 8-2.5A4.5 4.5 0 0 1 20 9c0 6-8 11-8 11z',
hourglass:'M7 3h10M7 21h10M8 3v4a4 4 0 0 0 1.6 3.2L12 12l2.4-1.8A4 4 0 0 0 16 7V3M8 21v-4a4 4 0 0 1 1.6-3.2L12 12l2.4 1.8A4 4 0 0 1 16 17v4',
folder:'M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z',
alarm:'M7 18v-6a5 5 0 0 1 10 0v6M5 18h14v3H5zM12 3v2M4.5 6.5L6 8M19.5 6.5L18 8',
search:'M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM20 20l-3.5-3.5',plus:'M12 5v14M5 12h14',arrow:'M5 12h14M13 6l6 6-6 6',chev:'M15 6l-6 6 6 6',
lock:'M5 11h14v10H5zM8 11V8a4 4 0 0 1 8 0v3',warn:'M12 4l9 16H3L12 4zM12 10v4M12 17h.01',
globe:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18',
logout:'M9 4H5v16h4M16 8l4 4-4 4M20 12H9',grid:'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z',
users:'M9 4a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7zM2.5 20c0-3.5 3-5.5 6.5-5.5s6.5 2 6.5 5.5M16 4.5a3.5 3.5 0 0 1 0 7M18.5 14.8c2 .7 3 2.3 3 5.2',
receipt:'M6 3h12v18l-3-2-3 2-3-2-3 2V3zM9 8h6M9 12h6',pulse:'M3 12h4l2-6 4 12 2-6h6',
trash:'M4 7h16M10 7V4h4v3M6 7l1 13h10l1-13M10 11v6M14 11v6',edit:'M4 20h4L19 9l-4-4L4 16v4zM13.5 6.5l4 4',
upload:'M12 16V4M7 9l5-5 5 5M4 20h16',image:'M4 5h16v14H4zM8 10a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zM4 17l5-5 4 4 3-3 4 4',
x:'M6 6l12 12M18 6L6 18',eye:'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z',
sliders:'M4 7h10M18 7h2M4 17h2M10 17h10M14 4v6M6 14v6',
wa:'M3.5 20.5l1.3-4.2A8.5 8.5 0 1 1 8 19.3l-4.5 1.2zM9 8.8c0 3.3 2.9 6.2 6.2 6.2l1.1-1.4-1.9-1-.9.7a4.3 4.3 0 0 1-2.1-2.1l.7-.9-1-1.9L9 8.8z',
bank:'M3 10l9-6 9 6M5 10v8M9.5 10v8M14.5 10v8M19 10v8M3 20h18',mobile:'M9.5 2.5h5a2 2 0 0 1 2 2v15a2 2 0 0 1-2 2h-5a2 2 0 0 1-2-2v-15a2 2 0 0 1 2-2zM11 18h2'
};
const ic=(n,s=22,w=2)=>`<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${P[n]||''}"/></svg>`;
const logo=(id,size)=>`<img src="/logo-mark.png" alt="${esc(t('appName'))}" style="height:${size}px;width:auto;max-width:none;display:block">`;
const catIcon={urgent:'alarm',active:'folder',review:'hourglass',water:'water',ramadan:'moon'};
const iconKeys={heart:'heart',building:'building',water:'water',drop:'drop'};

/* ---------- small ui builders ---------- */
const pill=(k,txt)=>`<span class="pill ${k||''}">${esc(txt)}</span>`;
const stPill=s=>pill(s==='verified'||s==='approved'?'':s==='pending'?'warn':s==='suspended'||s==='rejected'?'bad':'mut',t('st_'+s));
const empty=k=>`<div class="empty">${esc(t(k))}</div>`;
const bd=ty=>`<span dir="ltr">${esc(ty.replace('-','−'))}</span>`;
const inp=(id,path,o={})=>`<input id="${id}" class="in${o.cls?' '+o.cls:''}" data-f="${path}"${o.r?' data-r="1"':''} type="${o.type||'text'}"${o.dir?` dir="${o.dir}"`:''}${o.im?` inputmode="${o.im}"`:''}${o.max?` maxlength="${o.max}"`:''}${o.ph?` placeholder="${esc(o.ph)}"`:''}${o.list?` list="${o.list}"`:''} value="${esc(gp(S.f,path)==null?'':gp(S.f,path))}" autocomplete="off">`;
const area=(id,path,rows)=>`<textarea id="${id}" class="in" rows="${rows||3}" data-f="${path}">${esc(gp(S.f,path)==null?'':gp(S.f,path))}</textarea>`;
const sel=(id,path,opts)=>`<select id="${id}" class="in" data-f="${path}">${opts.map(([v,l])=>`<option value="${esc(v)}"${String(gp(S.f,path)==null?'':gp(S.f,path))===String(v)?' selected':''}>${esc(l)}</option>`).join('')}</select>`;
const lab=(id,k)=>`<label for="${id}">${esc(t(k))}</label>`;
const daysLeft=c=>{if(!c.deadline)return null;const ms=new Date(c.deadline+'T23:59:59')-Date.now();return Math.max(0,Math.ceil(ms/864e5))};
function prog(c){const don=S.D.donations.filter(d=>d.caseId===c.id);const raised=(Number(c.baseRaised)||0)+sum(don,d=>d.amount);const goal=Number(c.goal)||0;
 const donors=(Number(c.baseDonors)||0)+new Set(don.map(d=>d.accountNo)).size;const pct=goal?Math.min(100,Math.round(raised/goal*100)):0;
 const dl=daysLeft(c);return{raised,goal,donors,pct,left:Math.max(0,goal-raised),dl,closed:(dl!==null&&dl<=0)||(goal>0&&raised>=goal)}}

/* ---------- server api ---------- */
async function api(url,body){
 const o={credentials:'same-origin',headers:{}};
 if(body!==undefined){o.method='POST';o.headers['Content-Type']='application/json';o.body=JSON.stringify(body)}
 const r=await fetch(url,o);let j=null;try{j=await r.json()}catch(e){}
 if(!r.ok){const e=new Error((j&&j.error)||('http_'+r.status));e.code=(j&&j.error)||('http_'+r.status);e.status=r.status;throw e}
 return j}
const errMsg=e=>{const k=e&&e.code;return (k&&Object.prototype.hasOwnProperty.call(T.ar,k))?t(k):t('err_generic')};
async function run(fn){try{await fn();return true}catch(e){console.warn(e);toast(errMsg(e));return false}}
const ss={get(k){try{return sessionStorage.getItem(k)}catch(e){return null}},set(k,v){try{sessionStorage.setItem(k,v)}catch(e){}},del(k){try{sessionStorage.removeItem(k)}catch(e){}}};
let polling=false,sig='',wasLogged=false,chkT=0;
async function poll(force){
 if(polling)return;polling=true;
 try{const st=await api('/api/state');S.offline=false;const s=JSON.stringify(st);
  if(s!==sig||force){sig=s;applyState(st)}
  if(!S.dbChecked){S.dbChecked=true;sched()}}
 catch(e){if(!S.dbChecked){S.dbChecked=true;S.offline=true;sched()}}
 finally{polling=false}}
function applyState(st){
 S.me=st.me;S.isAdmin=!!(st.me&&st.me.roles&&st.me.roles[PAGE]);S.cred=st.me&&st.me.user?{acc:st.me.user.acc}:null;
 ['cases','charities','donors','donations','accounts','ledger','requests','donor_requests','topups','activity','withdrawals'].forEach(k=>{S.D[k]=st[k]||[]});
 S.D.settings=[Object.assign({id:'main'},st.settings||{})];S.D.myLedger=st.myLedger||[];S.D.myTopups=st.myTopups||[];
 S.accountDoc=st.accountDoc||null;S.requestDoc=st.requestDoc||null;S.myDonorReq=st.myDonorReq||null;S.myDonor=!!st.myDonor;S.myBS=st.myBloodSearches||[];S.D.blood_searches=st.blood_searches||[];S.accLoaded=true;
 notifyChanges(st);wasLogged=isLoggedIn();sched()}

/* ---------- auth flow ---------- */
async function doLogin(){
 const acc=digits(S.f.acc||'').trim(),code=String(S.f.code||'');S.err='';
 if(!/^[A-Za-z0-9\-]{4,20}$/.test(acc)){S.err=t('err_acc');return sched()}
 if(code.length<4||code.length>64){S.err=t('err_code');return sched()}
 S.busy=true;sched();
 try{
  const r=await api('/api/login',{acc,code});
  S.codePlain='';S.gateShown=false;wasLogged=false;S.view='home';S.f={};
  await poll(true);
 }catch(e){S.err=errMsg(e)}
 finally{S.busy=false;sched()}}
async function doRegister(){const f=S.f.rg||{};S.err='';
 const first=String(f.first||'').trim(),last=String(f.last||'').trim(),phone=digits(f.phone||'').replace(/\D/g,'').replace(/^222/,''),nid=digits(f.nid||'').replace(/\s/g,''),pw=String(f.pw||''),pw2=String(f.pw2||'');
 if(first.length<2||last.length<2){S.err=t('err_first');return sched()}
 if(!/^\d{8}$/.test(phone)){S.err=t('err_phone');return sched()}
 if(!/^\d{8,14}$/.test(nid)){S.err=t('err_nid');return sched()}
 if(pw.length<6||pw.length>64){S.err=t('err_pwlen');return sched()}
 if(pw!==pw2){S.err=t('err_pwmatch');return sched()}
 S.busy=true;sched();
 try{await api('/api/register',{first,last,phone,nid,password:pw,password2:pw2});S.f={};S.authMode='login';S.view='home';wasLogged=false;await poll(true);openWA()}
 catch(e){S.err=errMsg(e)}
 finally{S.busy=false;sched()}}
async function logout(){
 try{await api('/api/logout',{})}catch(e){}
 S.codePlain='';ss.del('dek_pcode');S.f={};S.view='home';S.gateShown=false;wasLogged=false;S.err='';S.authMode='login';seen.cases=null;
 await poll(true);sched()}
async function adminLogin(){
 const pw=String(S.f.adminpw||'');S.err='';if(!pw)return;S.busy=true;sched();
 try{await api('/api/admin/login',{password:pw,role:PAGE});S.f.adminpw='';await poll(true)}catch(e){S.err=errMsg(e)}
 finally{S.busy=false;sched()}}
async function adminLogout(){try{await api('/api/admin/logout',{role:PAGE})}catch(e){}S.view=ISPANEL?'admin':'home';S.f={};await poll(true);sched()}
async function pwSave(){
 const f=S.f.pw||{};S.err='';
 if(String(f.next||'').length<8||f.next!==f.again){S.err=t('err_pw');return sched()}
 const ok=await run(async()=>{await api('/api/admin/password',{role:PAGE,current:f.cur||'',next:f.next});toast(t('saved'))});
 if(ok)S.f.pw={cur:'',next:'',again:''};sched()}

/* ---------- user actions ---------- */
async function donateCharity(){const id=S.modal&&S.modal.id,amt=Math.floor(num(S.f.donate));S.err='';
 if(!(amt>0)){S.err=t('err_amount');return sched()}
 if(amt>myBalance()){S.err=t('err_insufficient');return sched()}
 S.busy=true;sched();
 try{await api('/api/action',{type:'donate',charityId:id,amount:amt});S.f.donate='';S.modal=null;await poll(true);toast(t('donated_ok'))}catch(e){S.err=errMsg(e)}
 S.busy=false;sched()}
async function saveProfile(){const pf=S.f.pf||{};S.busy=true;S.err='';sched();
 try{await api('/api/action',{type:'profile_save',name:String(pf.name||'').trim(),photo:pf.photo||'',removePhoto:!!pf.rm});S.f.pf=null;await poll(true);toast(t('saved'))}catch(e){S.err=errMsg(e)}
 S.busy=false;sched()}
async function donate(){
 const c=S.D.cases.find(x=>x.id===S.caseId);if(!c)return;const amt=Math.floor(num(S.f.donate));S.err='';
 if(!(amt>0)){S.err=t('err_amount');return sched()}
 if(amt>myBalance()){S.err=t('err_insufficient');return sched()}
 S.busy=true;sched();
 try{await api('/api/action',{type:'donate',caseId:c.id,amount:amt});S.f.donate='';await poll(true);toast(t('donated_ok'))}catch(e){S.err=errMsg(e)}
 S.busy=false;sched()}
async function submitTopup(){
 const f=S.f,amt=Math.floor(num(f.t_amount)),m=f.t_method||'bankily',ref=String(f.t_ref||'').trim();S.err='';
 if(!(amt>0)){S.err=t('err_amount');return sched()}
 if(ref.length<3){S.err=t('err_ref');return sched()}
 if(!f.t_receipt){S.err=t('err_receipt');return sched()}
 S.busy=true;sched();
 try{await api('/api/action',{type:'topup',method:m,amount:amt,ref,receipt:f.t_receipt||''});S.f.t_amount='';S.f.t_ref='';S.f.t_receipt='';await poll(true);toast(t('topup_sent'))}catch(e){S.err=errMsg(e)}
 S.busy=false;sched()}
async function submitDonor(){
 const f=S.f.dn||{};S.err='';const phone=digits(f.phone||'').replace(/\D/g,'').replace(/^222/,'');
 if(!String(f.name||'').trim()){S.err=t('err_name');return sched()}
 if(!/^\d{8}$/.test(phone)){S.err=t('err_phone');return sched()}
 S.busy=true;sched();
 try{await api('/api/action',{type:'donor_request',name:String(f.name).trim(),city:String(f.city||'').trim(),phone,bloodType:f.type||'O+'})}catch(e){S.err=errMsg(e);S.busy=false;return sched()}
 S.modal=null;await poll(true);toast(t('donor_sent'));S.busy=false;sched()}
async function revealPhone(id){
 try{const r=await api('/api/donor-phone/'+encodeURIComponent(id));S.revealed[id]=String(r.phone||'');sched()}catch(e){toast(errMsg(e))}}

/* ---------- images ---------- */
function loadImg(file){return new Promise((res,rej)=>{const u=URL.createObjectURL(file);const i=new Image();i.onload=()=>{URL.revokeObjectURL(u);res(i)};i.onerror=()=>{URL.revokeObjectURL(u);rej(new Error('img'))};i.src=u})}
async function shrink(file,max,q){const img=await loadImg(file);const k=Math.min(1,max/Math.max(img.naturalWidth,img.naturalHeight));const w=Math.max(1,Math.round(img.naturalWidth*k)),h=Math.max(1,Math.round(img.naturalHeight*k));
 const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,w,h);x.drawImage(img,0,0,w,h);return c.toDataURL('image/jpeg',q)}
async function toDataUrl(file,max,limit){let q=.8,out='';for(let i=0;i<6;i++){out=await shrink(file,max,q);if(out.length<limit)return out;max=Math.round(max*.82);q=Math.max(.45,q-.07)}if(out.length<limit*1.4)return out;throw {code:'err_image'}}
async function uploadImg(file,priv){const dataUrl=await toDataUrl(file,1400,900000);const r=await api('/api/upload',{dataUrl,private:!!priv});return r.url}
async function onFile(kind,file){if(!file)return;
 await run(async()=>{
  if(kind==='receipt'){S.f.t_receipt=await toDataUrl(file,1200,420000)}
  else if(kind==='avatar'){S.f.pf=S.f.pf||{};S.f.pf.photo=await toDataUrl(file,320,140000);S.f.pf.rm=false}
  else if(kind==='case'){S.f.cf.image=await uploadImg(file,false)}
  else if(kind==='tx'){S.f.tx=S.f.tx||{};S.f.tx.image=await uploadImg(file,true)}
  sched()})}

/* ---------- views: shell ---------- */
function header(){const li=S.cred&&isLoggedIn()&&S.view!=='admin';
 const nav=[['home','nav_home'],['cases','nav_cases'],['wallet','nav_wallet'],['account','nav_account']];
 const cur=S.view==='case'?'cases':S.view;
 return `<header class="top"><div class="wrap bar">
 <button class="brand ghost" data-a="go" data-v="home" style="color:inherit"><span class="lg geo">${logo('lgh',34)}</span><span>${esc(t('appName'))}</span></button>
 ${li?`<nav class="tnav" aria-label="main">${nav.map(([v,k])=>`<button data-a="go" data-v="${v}" class="${cur===v?'on':''}">${esc(t(k))}</button>`).join('')}</nav>`:''}
 <div class="bar-end">
 ${ISPANEL?`<a class="btn-s" href="/">${ic('home',18)}<span class="lbl">${esc(t('back_site'))}</span></a>`:''}
 <button class="btn-s" data-a="lang" aria-label="language">${ic('globe',18)}<span>${S.lang==='ar'?'English':'العربية'}</span></button>
 </div></div></header>`}
function bnav(){if(!(S.cred&&isLoggedIn())||S.view==='admin')return '';const cur=S.view==='case'?'cases':S.view;
 const items=[['home','home','nav_home'],['cases','list','nav_cases'],['wallet','wallet','nav_wallet'],['account','user','nav_account']];
 return `<nav class="bnav" aria-label="main">${items.map(([v,i,k])=>`<button data-a="go" data-v="${v}" class="${cur===v?'on':''}"><span class="pillx">${ic(i,22)}</span><span>${esc(t(k))}</span></button>`).join('')}</nav>`}
function layout(){let m;
 if(!S.dbChecked)m=screenLoading();else if(S.view==='admin')m=adminGate();else m=siteMain();
 return header()+`<main class="wrap main">${m}</main>`+bnav()+modalHtml()+(S.toast?`<div class="toast" role="status"><div>${esc(S.toast)}</div></div>`:'')}
function render(){const ae=document.activeElement;const id=ae&&ae.id;let a=null,b=null;if(id&&'selectionStart' in ae){try{a=ae.selectionStart;b=ae.selectionEnd}catch(e){}}
 document.documentElement.lang=S.lang;document.documentElement.dir=S.lang==='ar'?'rtl':'ltr';
 root.innerHTML=layout();
 if(id){const n=document.getElementById(id);if(n){try{n.focus({preventScroll:true});if(a!=null)n.setSelectionRange(a,b)}catch(e){}}}}
function screenLoading(){return `<div class="spin" role="status" aria-label="loading"></div>`}
function siteMain(){
 if(S.offline)return `<div class="auth"><div class="card" style="text-align:center"><h2>${esc(t('dbOff_title'))}</h2><p class="mut" style="margin-top:8px">${esc(t('dbOff_text'))}</p></div></div>`;
 if(!S.cred)return screenLogin();if(!S.accLoaded)return screenLoading();if(!isLoggedIn())return (accSt()==='suspended'||accSt()==='rejected')?screenGate():screenLogin();
 if(notifStatus()!=='granted')return screenNotif();
 return trialBanner()+siteView()}
function siteView(){
 switch(S.view){case 'cases':return viewCases();case 'case':return viewCase();case 'wallet':return viewWallet();case 'blood':return viewBlood();case 'charities':return viewCharities();case 'account':return viewAccount();default:return viewHome()}}

/* ---------- views: auth ---------- */
function screenLogin(){if(S.authMode==='register')return screenRegister();return `<section class="auth">
 <div class="auth-hero geo"><div class="lg">${logo('lgl',54)}</div><h1>${esc(t('appName'))}</h1><p>${esc(t('tagline'))}</p></div>
 <form class="card auth-card" data-form="login" autocomplete="off">
  <h2>${esc(t('login_title'))}</h2><p class="mut" style="margin-top:4px">${esc(t('login_sub'))}</p>
  ${lab('f-acc','phone_login')}
  <div class="field" dir="ltr">${ic('user')}<span class="pfx">+222</span>${inp('f-acc','acc',{dir:'ltr',im:'tel',max:15,ph:t('phone_ph')})}</div>
  ${lab('f-code','code_label')}
  <div class="field">${ic('lock')}${inp('f-code','code',{dir:'ltr',max:64,type:S.showCode?'text':'password',ph:'••••••'})}<button type="button" class="ghost" data-a="toggle-code" aria-label="${esc(t('show'))}">${ic('eye',20)}</button></div>
  ${S.err?`<div class="alert bad" role="alert">${esc(S.err)}</div>`:''}
  <button class="btn" type="submit"${S.busy?' disabled':''}>${esc(S.busy?t('checking'):t('verify_btn'))}</button>
 <button type="button" class="btn o" style="margin-top:10px" data-a="auth-mode" data-m="register">${esc(t('new_acc'))}</button>
 ${abroadBox()}</form><p class="terms">${esc(t('terms'))}</p></section>`}
function screenRegister(){const eye=`<button type="button" class="ghost" data-a="toggle-code" aria-label="${esc(t('show'))}">${ic('eye',20)}</button>`,ty=S.showCode?'text':'password';
 return `<section class="auth"><div class="auth-hero geo"><div class="lg">${logo('lgl',54)}</div><h1>${esc(t('appName'))}</h1><p>${esc(t('tagline'))}</p></div>
 <form class="card auth-card" data-form="register" autocomplete="off"><h2>${esc(t('reg_title'))}</h2><p class="mut" style="margin-top:4px">${esc(t('reg_sub'))}</p>
 <div class="g2"><div>${lab('r-first','first_name')}${inp('r-first','rg.first',{max:30})}</div><div>${lab('r-last','last_name')}${inp('r-last','rg.last',{max:30})}</div></div>
 ${lab('r-phone','phone')}<div class="field" dir="ltr"><span class="pfx">+222</span>${inp('r-phone','rg.phone',{dir:'ltr',im:'numeric',max:12,ph:t('phone_ph')})}</div>
 ${lab('r-nid','nid')}${inp('r-nid','rg.nid',{dir:'ltr',im:'numeric',max:14})}
 ${lab('r-pw','pw_label')}<div class="field">${ic('lock')}${inp('r-pw','rg.pw',{dir:'ltr',max:64,type:ty})}${eye}</div>
 ${lab('r-pw2','pw2_label')}<div class="field">${ic('lock')}${inp('r-pw2','rg.pw2',{dir:'ltr',max:64,type:ty})}</div>
 ${S.err?`<div class="alert bad" role="alert">${esc(S.err)}</div>`:''}
 <button class="btn" type="submit"${S.busy?' disabled':''} style="margin-top:14px">${esc(t('send_info'))}</button>
 <button type="button" class="btn o" style="margin-top:10px" data-a="auth-mode" data-m="login">${esc(t('have_acc'))}</button>${abroadBox()}</form><p class="terms">${esc(t('terms'))}</p></section>`}
function screenGate(){const rj=accSt()==='rejected';return `<section class="auth"><div class="card" style="margin-top:20px;padding:22px 18px"><div style="margin-bottom:10px">${pill('bad',t(rj?'st_rejected':'st_suspended'))}</div>
 <h2 style="font-size:22px;font-weight:800">${esc(t(rj?'rejected_title':'suspended_title'))}</h2><p class="mut" style="margin-top:6px">${esc(t(rj?'err_rejected':'err_suspended'))}</p>
 <button class="btn o" style="margin-top:16px" data-a="logout">${esc(t('switch_acc'))}</button></div></section>`}
const waNum=()=>{const s=S.D.settings.find(x=>x.id==='main');return String((s&&s.whatsapp)||WA_DEFAULT).replace(/\D/g,'')};
function waLink(){const a=S.accountDoc||{};const msg=S.lang==='ar'
 ?`السلام عليكم، أرغب في توثيق حسابي في دار الخير.\nالاسم: ${a.name||''}\nالهاتف: ${a.phone||a.accountNo||''}\nرمز الطلب: ${a.ref||''}`
 :`Hello, I would like to verify my Dar El Kheir account.\nName: ${a.name||''}\nPhone: ${a.phone||a.accountNo||''}\nRequest code: ${a.ref||''}`;
 return 'https://wa.me/'+waNum()+'?text='+encodeURIComponent(msg)}
function waOutLink(){const m=S.lang==='ar'?'السلام عليكم، أنا خارج الوطن وأرغب في توثيق حسابي في دار الخير.':'Hello, I am outside the country and I would like to verify my Dar El Kheir account.';return 'https://wa.me/'+waNum()+'?text='+encodeURIComponent(m)}
const abroadBox=()=>`<div class="alert ok" style="margin-top:14px;display:flex;gap:10px;align-items:center;flex-wrap:wrap"><span style="flex:1;min-width:160px"><b>${esc(t('abroad_q'))}</b> ${esc(t('abroad_txt'))}</span><a class="btn-s pri" href="${esc(waOutLink())}" target="_blank" rel="noopener">${ic('phone',18)}<span>${esc(t('abroad_btn'))}</span></a></div>`;
const openWA=()=>{try{window.open(waLink(),'_blank','noopener')}catch(e){}};
function trialBanner(){if(accSt()!=='pending')return '';
 return `<div class="alert warn" style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-top:0"><span style="flex:1;min-width:200px"><b>${esc(t('trial_title'))}</b><br>${esc(t('trial_note'))}</span><button class="btn-s pri" data-a="wa">${ic('phone',18)}<span>${esc(t('trial_wa'))}</span></button></div>`}
/* ---------- notifications (required) ---------- */
const notifStatus=()=>{if(ISPANEL)return 'granted';if(typeof Notification==='undefined')return 'unsupported';return Notification.permission};
function screenNotif(){const st=notifStatus();
 return `<section class="auth"><div class="card" style="margin-top:20px;padding:22px 18px;text-align:center"><div style="font-size:42px">🔔</div>
 <h2 style="font-size:22px;font-weight:800;margin-top:6px">${esc(t('notif_title'))}</h2>
 <p class="mut" style="margin-top:8px;line-height:1.8">${esc(t(st==='denied'?'notif_denied':st==='unsupported'?'notif_unsupported':'notif_text'))}</p>
 ${st==='default'?`<button class="btn" style="margin-top:16px" data-a="notif-on">${esc(t('notif_btn'))}</button>`:`<button class="btn" style="margin-top:16px" data-a="notif-check">${esc(t('notif_recheck'))}</button>`}
 <button class="btn o" style="margin-top:10px" data-a="logout">${esc(t('logout'))}</button></div></section>`}
function notify(title,body){try{if(typeof Notification==='undefined'||Notification.permission!=='granted')return;
 const o={body:body||'',icon:'/icon-192.png',tag:title+'|'+(body||'')};
 if(navigator.serviceWorker&&navigator.serviceWorker.getRegistration){navigator.serviceWorker.getRegistration().then(r=>{if(r)r.showNotification(title,o);else new Notification(title,o)}).catch(()=>{try{new Notification(title,o)}catch(e){}})}
 else new Notification(title,o)}catch(e){}}
const seen={cases:null,tops:null,st:null};
function notifyChanges(st){
 if(PAGE!=='site'||!st.me||!st.me.user){seen.cases=null;return}
 const cs=st.cases||[],tops={};(st.myTopups||[]).forEach(x=>{tops[x.id]=x.status});const s0=st.accountDoc&&st.accountDoc.status;
 if(seen.cases){
  cs.filter(c=>!seen.cases.includes(c.id)&&c.category!=='review').forEach(c=>notify(t('n_new_case'),loc(c.title)));
  Object.keys(tops).forEach(id=>{if(seen.tops[id]==='pending'&&tops[id]!=='pending')notify(t(tops[id]==='approved'?'n_top_ok':'n_top_no'),'')});
  if(seen.st==='pending'&&s0==='verified')notify(t('verified_now'),'')}
 seen.cases=cs.map(c=>c.id);seen.tops=tops;seen.st=s0}

/* ---------- views: home ---------- */
function walletCard(withBtn){const b=myBalance();return `<div class="wallet geo"><div class="row"><b>${esc(t('wallet_balance'))}</b><span class="ico">${ic('wallet',20)}</span></div>
 <div class="amt num"><span>${fmt(b)}</span><small>MRU</small></div>
 <div class="row" style="margin-top:14px"><span class="tip">${esc(t('wallet_hint'))}</span>${withBtn?`<button class="wbtn" data-a="go" data-v="wallet">${ic('plus',18,2.6)}<span>${esc(t('topup_btn'))}</span></button>`:''}</div></div>`}
function caseCard(c){const p=prog(c);const src=imgSrc(c);
 return `<button class="ccard" data-a="case" data-id="${esc(c.id)}"><div class="cimg geo">${src?`<img src="${esc(src)}" alt="" loading="lazy">`:ic(catIcon[c.category]||'heart',44,1.6)}<span class="tag">${pill(c.category==='urgent'?'hot':c.category==='review'?'warn':'',t('cat_'+(c.category||'active')))}</span></div>
 <div class="cbody"><h4>${esc(loc(c.title))}</h4><div class="loc">${ic('pin',16)}<span>${esc(loc(c.location))}</span></div>
 <div class="bar-p" role="progressbar" aria-valuenow="${p.pct}" aria-valuemin="0" aria-valuemax="100"><i style="width:${p.pct}%"></i></div>
 <div class="row2"><span><b class="num">${fmt(p.raised)}</b> / <span class="num">${fmt(p.goal)}</span> MRU</span><span>${p.dl!==null?esc(t('days_n',{n:p.dl})):''}</span></div></div></button>`}
function viewHome(){const nm=S.accountDoc&&S.accountDoc.name;
 const tiles=METHODS.map(m=>`<button class="tile" data-a="topup-method" data-m="${m}"><span class="bx">${ic(m==='bankily'?'mobile':m==='masrvi'?'bank':'receipt',20)}</span><span>${esc(t('m_'+m))}</span></button>`).join('');
 const sect=(v,ic_,k,hot,extra)=>`<button class="sect${hot?' hot':''}" data-a="${extra||'go'}" ${extra?`data-f2="${v}"`:`data-v="${v}"`}><span class="bx">${ic(ic_,24)}</span><span>${esc(t(k))}</span></button>`;
 const latest=S.D.cases.filter(c=>c.category!=='review').slice().sort((a,b)=>String(b.createdAt||'').localeCompare(String(a.createdAt||''))).slice(0,3);
 return `<div class="hello"><small>${esc(t('salaam'))}</small><h1 dir="auto">${esc(nm||S.cred.acc)}</h1></div>
 <div class="duo"><div>${walletCard(true)}</div><div><h3 class="sec" style="margin-top:0">${esc(t('topup_methods'))}</h3><div class="tiles">${tiles}</div></div></div>
 <h3 class="sec">${esc(t('sections'))}</h3><div class="sects">
 ${sect('urgent','alarm','cat_urgent',true,'cases-f')}${sect('active','folder','cat_active',false,'cases-f')}${sect('review','hourglass','cat_review',false,'cases-f')}
 ${sect('water','water','cat_water',false,'cases-f')}${sect('ramadan','moon','cat_ramadan',false,'cases-f')}${sect('blood','drop','blood')}${sect('charities','building','charities')}</div>
 ${latest.length?`<h3 class="sec">${esc(t('latest'))}</h3><div class="gcases">${latest.map(caseCard).join('')}</div>`:''}`}

/* ---------- views: cases ---------- */
function viewCases(){const f=S.casesFilter;const list=S.D.cases.filter(c=>f==='all'||c.category===f).slice().sort((a,b)=>String(b.createdAt||'').localeCompare(String(a.createdAt||'')));
 return `<h1 style="font-size:24px;font-weight:800;margin-block:8px 6px">${esc(t('nav_cases'))}</h1>
 <div class="chips">${['all'].concat(CATS).map(c=>`<button class="chip${f===c?' on':''}" data-a="cases-f" data-f2="${c}">${esc(t('cat_'+c))}</button>`).join('')}</div>
 ${list.length?`<div class="gcases">${list.map(caseCard).join('')}</div>`:empty('no_cases')}`}
function viewCase(){const c=S.D.cases.find(x=>x.id===S.caseId);
 if(!c)return `<button class="back" data-a="go" data-v="cases"><span class="flip">${ic('arrow',20)}</span>${esc(t('back'))}</button>${empty('no_cases')}`;
 const p=prog(c),b=myBalance(),src=imgSrc(c),review=c.category==='review',blocked=review||p.closed,noBal=b<=0;
 const unver=!isVerified();const dis=blocked||noBal||unver||S.busy;
 return `<button class="back" data-a="go" data-v="cases"><span class="flip">${ic('arrow',20)}</span>${esc(t('back'))}</button>
 <div class="detail"><div><div class="dhero geo">${src?`<img src="${esc(src)}" alt="">`:ic(catIcon[c.category]||'heart',72,1.4)}</div>
 <div class="card" style="margin-top:14px"><h2 style="font-size:24px;font-weight:800">${esc(loc(c.title))}</h2>
 <div class="loc" style="margin-top:4px">${ic('pin',17)}<span>${esc(loc(c.location))}</span> ${pill('',t('verified_badge'))}</div>
 <div class="stat2"><div class="stat">${ic('users',22)}<span><b class="num">${fmt(p.donors)}</b> <span class="mut">${esc(t('donors_n'))}</span></span></div>
 <div class="stat">${ic('hourglass',22)}<span><b class="num">${p.dl===null?'—':p.dl}</b> <span class="mut">${esc(t('days_label'))}</span></span></div></div>
 <div class="row2" style="align-items:flex-end"><span>${esc(t('raised'))}<br><b class="num" style="font-size:19px;color:var(--brand-ink)">${fmt(p.raised)} MRU</b></span><span style="text-align:end">${esc(t('goal'))}<br><b class="num" style="font-size:19px">${fmt(p.goal)} MRU</b></span></div>
 <div class="bar-p" style="height:12px;margin-top:8px"><i style="width:${p.pct}%"></i></div>
 <div class="row2" style="margin-top:6px"><b style="color:var(--brand-ink)">${p.pct}% ${esc(t('funded'))}</b><span class="num">${esc(t('remaining'))} ${fmt(p.left)} MRU</span></div>
 <h3 class="sec" style="margin-block:16px 4px">${esc(t('story'))}</h3><p class="mut" style="line-height:1.8">${esc(loc(c.story))}</p></div></div>
 <div class="card">
 ${review?`<div class="alert warn" style="margin-top:0">${esc(t('review_note'))}</div>`:p.closed?`<div class="alert warn" style="margin-top:0">${esc(t('closed_note'))}</div>`:unver?`<div class="alert warn" style="margin-top:0">${esc(t('trial_block'))}</div>`:noBal?`<div class="alert warn" style="margin-top:0;display:flex;gap:10px;align-items:center">${ic('warn',24)}<span>${esc(t('need_topup'))}<br><small style="font-weight:500">${esc(t('your_balance',{n:fmt(b)}))}</small></span></div>`:''}
 ${!blocked&&!noBal&&!unver?`${lab('f-donate','donate_amount')}${inp('f-donate','donate',{im:'numeric',dir:'ltr',ph:'500'})}
 <div class="amts">${[100,200,500,1000].map(n=>`<button class="chip" data-a="amt" data-n="${n}">${n}</button>`).join('')}</div>
 <p class="mut" style="margin-top:8px;font-size:13.5px">${esc(t('your_balance',{n:fmt(b)}))}</p>`:''}
 ${S.err?`<div class="alert bad" role="alert">${esc(S.err)}</div>`:''}
 <button class="btn" style="margin-top:14px" data-a="donate"${dis?' disabled':''}>${ic('lock',20,2.2)}<span>${esc(t('donate_btn'))}</span></button>
 ${noBal&&!blocked&&!unver?`<button class="btn o" style="margin-top:10px" data-a="go" data-v="wallet">${ic('wallet',20)}<span>${esc(t('topup_now'))}</span></button>`:''}</div></div>`}

/* ---------- views: wallet ---------- */
function histList(){return [].concat(
  S.D.myLedger.map(x=>({at:x.at,k:x.source==='admin'&&!x.topupId?'adj':'topup',amt:Number(x.amount)||0,st:'approved',sub:x.method?t('m_'+x.method):''})),
  S.D.myTopups.filter(x=>x.status!=='approved').map(x=>({at:x.at,k:'topup',amt:Number(x.amount)||0,st:x.status,sub:t('m_'+x.method)})),
  S.D.donations.filter(x=>x.accountNo===S.cred.acc).map(x=>{const c=S.D.cases.find(y=>y.id===x.caseId),h=x.charityId&&S.D.charities.find(y=>y.id===x.charityId);return{at:x.at,k:'don',amt:-(Number(x.amount)||0),st:'approved',sub:c?loc(c.title):h?loc(h.name):''}})
 ).sort((a,b)=>String(b.at||'').localeCompare(String(a.at||'')));
}
function viewWallet(){const m=S.f.t_method||'bankily';
 const hist=histList();
 const number=payNum(m);
 return `<h1 style="font-size:24px;font-weight:800;margin-block:8px 12px">${esc(t('nav_wallet'))}</h1>
 <div class="duo"><div>${walletCard(false)}</div>
 ${!isVerified()?`<div class="card"><div class="alert warn" style="margin:0">${esc(t('trial_block'))}</div></div>`:`<form class="card" data-form="topup"><h3 style="font-weight:800;font-size:17px">${esc(t('topup_title'))}</h3><p class="mut" style="font-size:13.5px;margin-top:2px">${esc(t('topup_how'))}</p>
 <label style="margin-top:12px">${esc(t('pay_method'))}</label>
 <div class="methods">${METHODS.map(x=>`<button type="button" class="mth${m===x?' on':''}" data-a="topup-method" data-m="${x}">${esc(t('m_'+x))}<small>${esc(payNum(x)||'')}</small></button>`).join('')}</div>
 <div class="alert ok" style="margin-top:12px">${esc(t('pay_to'))}: <b dir="ltr">${esc(number||t('not_set'))}</b></div>
 ${lab('f-tamount','amount')}${inp('f-tamount','t_amount',{im:'numeric',dir:'ltr'})}
 ${lab('f-tref','tx_ref')}${inp('f-tref','t_ref',{dir:'ltr',max:40})}
 ${lab('f-treceipt','receipt')}<input id="f-treceipt" class="in" type="file" accept="image/*" data-file="receipt" style="padding-top:12px">
 ${S.f.t_receipt?`<img class="pv" src="${esc(S.f.t_receipt)}" alt="">`:''}
 ${S.err?`<div class="alert bad" role="alert">${esc(S.err)}</div>`:''}
 <button class="btn" style="margin-top:16px" type="submit"${S.busy?' disabled':''}>${esc(t('send_req'))}</button></form>`}</div>
 <h3 class="sec">${esc(t('history'))}</h3>
 ${hist.length?`<div class="list">${hist.map(h=>`<div class="item"><span class="bx" style="width:40px;height:40px;border-radius:12px;background:var(--soft);display:grid;place-items:center;color:var(--brand)">${ic(h.k==='don'?'heart':'receipt',20)}</span>
  <div class="grow"><div class="t1">${esc(h.k==='don'?t('tx_donation'):h.k==='adj'?t('tx_adjust'):t('tx_topup'))}</div><div class="t2">${esc(h.sub)} · ${esc(fmtDate(h.at))}</div></div>
  <div style="text-align:end"><div class="amtp${h.amt<0?' neg':''}" dir="ltr">${h.amt>0?'+':'−'}${fmt(Math.abs(h.amt))} MRU</div>${h.st!=='approved'?stPill(h.st):''}</div></div>`).join('')}</div>`:empty('no_history')}`}

/* ---------- views: blood bank ---------- */
const mask=p=>{const d=String(p||'').replace(/\D/g,'');return d.length===8?'+222 '+d.slice(0,2)+' •• •• '+d.slice(6):'••••'};
const bsBadge=st=>`<span class="mut" style="font-weight:700;color:${st==='found'?'var(--brand)':st==='closed'?'#888':'#c2410c'}">${esc(t('bs_'+st))}</span>`;
function viewBlood(){const req=S.myDonorReq&&S.myDonorReq.status==='pending';const mine=S.myBS||[];
 return `<button class="back" data-a="go" data-v="home"><span class="flip">${ic('arrow',20)}</span>${esc(t('back'))}</button>
 <h1 style="font-size:24px;font-weight:800;margin-bottom:10px">${esc(t('blood'))}</h1>
 <div class="card" style="max-width:560px"><div style="display:flex;gap:12px;align-items:center"><span class="bt" style="width:48px;height:48px;border-radius:14px;background:var(--soft);display:grid;place-items:center;color:var(--brand)">${ic('drop',24)}</span><b style="font-size:17px">${esc(t('bs_title'))}</b></div>
 <p class="mut" style="margin:10px 0 4px;line-height:1.8;font-size:14px">${esc(t('bs_note'))}</p>
 ${lab('bs-h','bs_hospital')}${inp('bs-h','bs.hospital')}${lab('bs-t','blood_type')}${sel('bs-t','bs.type',BLOOD.map(b=>[b,b.replace('-','−')]))}${lab('bs-w','bs_wilaya')}${sel('bs-w','bs.wilaya',WILAYAS.map((w,i)=>[String(i),S.lang==='ar'?w[0]:w[1]]))}
 ${S.err?`<div class="alert bad" role="alert">${esc(S.err)}</div>`:''}
 <div style="margin-top:14px"><button class="btn" data-a="bs-send"${S.busy?' disabled':''}>${ic('drop',20,2.4)}<span>${esc(t('bs_send'))}</span></button></div></div>
 ${mine.length?`<div class="card" style="max-width:560px;margin-top:14px"><b>${esc(t('bs_mine'))}</b>${mine.map(r=>`<div style="display:flex;justify-content:space-between;gap:10px;align-items:center;padding:10px 0;border-top:1px solid var(--line,#e5e5e5);margin-top:8px"><span>${esc(r.hospital)} · ${esc(wname(r.wilaya))} · <b dir="ltr">${esc(String(r.bloodType).replace('-','−'))}</b></span>${bsBadge(r.status)}</div>`).join('')}</div>`:''}
 <div class="card" style="max-width:560px;margin-top:14px">${S.myDonor?`<div class="alert ok" style="margin:0">${esc(t('donor_you'))}</div>`:req?`<div class="alert warn" style="margin:0">${esc(t('donor_review'))}</div>`:`<button class="btn o" data-a="donor-open">${ic('drop',20,2.4)}<span>${esc(t('register_donor'))}</span></button>`}</div>`}
async function submitBS(){
 const f=S.f.bs||{};S.err='';
 if(!String(f.hospital||'').trim()){S.err=t('err_hospital');return sched()}
 S.busy=true;sched();
 try{await api('/api/action',{type:'blood_search',hospital:String(f.hospital).trim(),bloodType:f.type||'A+',wilaya:Number(f.wilaya)||0});S.f.bs={hospital:'',type:f.type||'A+',wilaya:f.wilaya||'0'};await poll(true);toast(t('bs_sent'))}catch(e){S.err=errMsg(e)}
 S.busy=false;sched()}

/* ---------- views: charities / account ---------- */
function viewCharities(){const q=String(S.chq||'').trim().toLowerCase();const list=S.D.charities.filter(c=>!q||(loc(c.name)+' '+loc(c.desc)).toLowerCase().includes(q));
 return `<button class="back" data-a="go" data-v="home"><span class="flip">${ic('arrow',20)}</span>${esc(t('back'))}</button>
 <div class="wallet geo" style="padding:18px 20px"><div style="display:flex;gap:12px;align-items:center"><span class="ico" style="width:44px;height:44px;border-radius:14px;background:rgba(255,255,255,.2);display:grid;place-items:center">${ic('shield',24)}</span>
 <div><b style="font-size:16px">${esc(t('ch_title'))}</b><div style="font-size:13px;opacity:.95">${esc(t('ch_sub'))}</div></div></div></div>
 <div class="sbox">${ic('search',22)}${inp('f-chq','chq',{r:1,ph:t('ch_search')})}</div>
 ${list.length?`<div class="gdon">${list.map(c=>`<div class="item" style="padding:14px"><span style="width:60px;height:60px;border-radius:18px;background:var(--soft);display:grid;place-items:center;color:var(--brand);flex:none">${ic(iconKeys[c.icon]||'heart',30,1.8)}</span>
 <div class="grow"><div class="t1">${esc(loc(c.name))} ${c.verified!==false?pill('',t('verified_badge')):''}</div><div class="t2">${esc(loc(c.desc))}</div></div><button class="btn-s pri" data-a="ch-donate" data-id="${esc(c.id)}">${ic('heart',18)}<span>${esc(t('do_donate'))}</span></button></div>`).join('')}</div>`:empty('no_ch')}`}
const avatar=(a,sz)=>`<span class="avt" style="width:${sz}px;height:${sz}px;border-radius:50%;background:var(--soft);color:var(--brand);display:grid;place-items:center;overflow:hidden;flex:none;font-weight:800;font-size:${Math.round(sz/2.4)}px">${a&&a.photo?`<img src="${esc(a.photo)}" alt="" style="width:100%;height:100%;object-fit:cover">`:esc(String((a&&a.name)||S.cred.acc).trim().charAt(0).toUpperCase()||'•')}</span>`;
function viewAccount(){const a=S.accountDoc;if(!S.f.pf)S.f.pf={name:(a&&a.name)||'',photo:'',rm:false};const pf=S.f.pf;
 const hist=histList(),inn=sum(hist.filter(h=>h.k!=='don'&&h.st==='approved'),h=>h.amt),out=sum(hist.filter(h=>h.k==='don'),h=>-h.amt);
 const shown=pf.photo?{photo:pf.photo,name:pf.name}:pf.rm?{name:pf.name}:{photo:a&&a.photo,name:pf.name};
 return `<h1 style="font-size:24px;font-weight:800;margin-block:8px 12px">${esc(t('account'))}</h1>
 <div class="duo"><div class="card"><div style="display:flex;gap:14px;align-items:center;margin-bottom:12px">${avatar(shown,72)}<div class="grow"><b dir="auto" style="font-size:18px">${esc(pf.name||S.cred.acc)}</b><div class="mut" dir="ltr" style="text-align:start">${esc(S.cred.acc)}</div></div></div>
 <form data-form="profile">${lab('f-pname','nick')}${inp('f-pname','pf.name',{max:40})}
 ${lab('f-pphoto','photo_pick')}<input id="f-pphoto" class="in" type="file" accept="image/*" data-file="avatar" style="padding-top:12px">
 ${(a&&a.photo)||pf.photo?`<button type="button" class="btn-s" style="margin-top:8px" data-a="photo-rm">${esc(t('photo_rm'))}</button>`:''}
 ${S.err?`<div class="alert bad" role="alert">${esc(S.err)}</div>`:''}<button class="btn" style="margin-top:14px" type="submit"${S.busy?' disabled':''}>${esc(t('save'))}</button></form>
 <div class="kv" style="margin-top:14px"><span class="mut">${esc(t('wallet_balance'))}</span><b class="num">${fmt(myBalance())} MRU</b></div>
 <div class="kv"><span class="mut">${esc(t('language'))}</span><button class="btn-s" data-a="lang">${ic('globe',18)}<span>${S.lang==='ar'?'English':'العربية'}</span></button></div>
 <button class="btn o" style="margin-top:16px" data-a="logout">${ic('logout',20)}<span>${esc(t('logout'))}</span></button></div>
 <div class="card"><div class="hd" style="margin-bottom:8px"><h3 style="font-weight:800;font-size:17px">${esc(t('statement'))}</h3><button class="btn-s" data-a="print">${esc(t('print'))}</button></div>
 <div class="kv"><span class="mut">${esc(t('st_in'))}</span><b class="amtp num" dir="ltr">+${fmt(inn)} MRU</b></div><div class="kv"><span class="mut">${esc(t('st_out'))}</span><b class="amtp neg num" dir="ltr">−${fmt(out)} MRU</b></div>
 ${hist.length?`<div class="list" style="margin-top:10px">${hist.map(h=>`<div class="item"><span class="bx" style="width:40px;height:40px;border-radius:12px;background:var(--soft);display:grid;place-items:center;color:var(--brand)">${ic(h.k==='don'?'heart':'receipt',20)}</span>
  <div class="grow"><div class="t1">${esc(h.k==='don'?t('tx_donation'):h.k==='adj'?t('tx_adjust'):t('tx_topup'))}</div><div class="t2">${esc(h.sub)} · ${esc(fmtDate(h.at))}</div></div>
  <div style="text-align:end"><div class="amtp${h.amt<0?' neg':''}" dir="ltr">${h.amt>0?'+':'−'}${fmt(Math.abs(h.amt))} MRU</div>${h.st!=='approved'?stPill(h.st):''}</div></div>`).join('')}</div>`:empty('no_history')}</div></div>`}

/* ---------- modal ---------- */
function modalHtml(){const m=S.modal;if(!m)return '';let body='';
 if(m.type==='confirm')body=`<h3>${esc(t('confirm'))}</h3><p class="mut">${esc(t('sure'))}</p><div class="foot"><button class="btn o" data-a="close">${esc(t('cancel'))}</button><button class="btn" data-a="confirm-yes">${esc(t('confirm'))}</button></div>`;
 else if(m.type==='img')body=`<img class="big" src="${esc(m.src)}" alt=""><div class="foot"><button class="btn o" data-a="close">${esc(t('close'))}</button></div>`;
 else if(m.type==='chdonate'){const ch=S.D.charities.find(x=>x.id===m.id),b=myBalance();body=`<h3>${esc(t('donate_to'))} ${esc(ch?loc(ch.name):'')}</h3>${!isVerified()?`<div class="alert warn">${esc(t('trial_block'))}</div><div class="foot"><button class="btn o" data-a="close">${esc(t('cancel'))}</button></div>`:b<=0?`<div class="alert warn">${esc(t('need_topup'))}</div><div class="foot"><button class="btn o" data-a="close">${esc(t('cancel'))}</button><button class="btn" data-a="ch-topup">${esc(t('topup_now'))}</button></div>`:`${lab('f-donate','donate_amount')}${inp('f-donate','donate',{im:'numeric',dir:'ltr',ph:'500'})}<div class="amts">${[100,200,500,1000].map(n=>`<button class="chip" data-a="amt" data-n="${n}">${n}</button>`).join('')}</div><p class="mut" style="margin-top:8px;font-size:13.5px">${esc(t('your_balance',{n:fmt(b)}))}</p>${S.err?`<div class="alert bad" role="alert">${esc(S.err)}</div>`:''}<div class="foot"><button class="btn o" data-a="close">${esc(t('cancel'))}</button><button class="btn" data-a="ch-donate-go"${S.busy?' disabled':''}>${esc(t('donate_btn'))}</button></div>`}`}
 else if(m.type==='donor')body=`<h3>${esc(t('register_donor'))}</h3><p class="mut" style="font-size:13.5px">${esc(t('appears_after'))}</p>
  ${lab('d-name','full_name')}${inp('d-name','dn.name')}${lab('d-type','blood_type')}${sel('d-type','dn.type',BLOOD.map(b=>[b,b.replace('-','−')]))}
  ${lab('d-city','city')}${inp('d-city','dn.city')}${lab('d-phone','phone')}${inp('d-phone','dn.phone',{dir:'ltr',im:'numeric',max:12})}
  ${S.err?`<div class="alert bad" role="alert">${esc(S.err)}</div>`:''}<div class="foot"><button class="btn o" data-a="close">${esc(t('cancel'))}</button><button class="btn" data-a="donor-save"${S.busy?' disabled':''}>${esc(t('send_req'))}</button></div>`;
 else body=adminModal(m);
 return `<div class="ovl" data-ovl="1"><div class="dlg" role="dialog" aria-modal="true">${body}</div></div>`}
function ask(cb){S.modal={type:'confirm',cb};sched()}

/* ---------- admin ---------- */
function adminGate(){if(S.isAdmin)return adminView();return `<section class="auth"><form class="card" data-form="adminlogin" style="margin-top:24px;padding:22px 18px" autocomplete="off"><h2 style="font-size:22px;font-weight:800">${esc(t(PAGE==='manage'?'panel_manage':PAGE==='topups'?'panel_topups':'admin_login_title'))}</h2><p class="mut" style="margin-top:4px">${esc(t('admin_login_sub'))}</p>${lab('f-adminpw','admin_pw')}<div class="field">${ic('lock')}${inp('f-adminpw','adminpw',{dir:'ltr',type:'password'})}</div>${S.err?`<div class="alert bad" role="alert">${esc(S.err)}</div>`:''}<button class="btn" type="submit"${S.busy?' disabled':''} style="margin-top:18px">${esc(t('sign_in'))}</button></form></section>`}
const D=()=>S.D;
const pendAcc=()=>D().accounts.filter(a=>a.status==='pending');
const pendTop=()=>D().topups.filter(r=>r.status==='pending');
const openBS=()=>(D().blood_searches||[]).filter(r=>r.status==='open');
const pendDon=()=>D().donor_requests.filter(r=>r.status==='pending');
function adminView(){
 const tabs=PAGE==='manage'?[['cases','folder',0],['charities','building',0],['security','lock',0]]:PAGE==='topups'?[['tx','receipt',pendTop().length],['security','lock',0]]:[['overview','grid',0],['accounts','users',pendAcc().length],['donors','drop',pendDon().length],['blood','pin',openBS().length],['activity','pulse',0],['reports','list',0],['settings','sliders',0]];
 if(!tabs.some(x=>x[0]===S.adminTab))S.adminTab=tabs[0][0];
 const tab=S.adminTab;let body='';
 if(tab==='overview')body=aOverview();else if(tab==='accounts')body=aAccounts();else if(tab==='tx')body=aTx();else if(tab==='cases')body=aCases();else if(tab==='donors')body=aDonors();else if(tab==='blood')body=aBlood();else if(tab==='charities')body=aCharities();else if(tab==='activity')body=aActivity();else if(tab==='reports')body=aReports();else if(tab==='security')body=aSecurity();else body=aSettings();
 return `<div class="hd" style="margin-block:8px"><h1 style="font-size:24px;font-weight:800">${esc(t(PAGE==='manage'?'panel_manage':PAGE==='topups'?'panel_topups':'admin_panel'))}</h1>${S.me&&S.me.local?'':`<button class="btn-s" data-a="admin-logout">${ic('logout',18)}<span>${esc(t('admin_logout'))}</span></button>`}</div>
 <div class="atabs" role="tablist">${tabs.map(([k,i,n])=>`<button class="atab${tab===k?' on':''}" role="tab" data-a="atab" data-k="${k}">${ic(i,18)}<span>${esc(t('tab_'+k))}</span>${n?`<em>${n}</em>`:''}</button>`).join('')}</div>${body}`}
const tbl=(heads,rows)=>`<div class="tw"><table class="tbl"><thead><tr>${heads.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>`;
function actRows(list){return list.map(a=>`<tr><td class="num" style="white-space:nowrap">${esc(fmtDate(a.at))}</td><td dir="ltr" style="text-align:start">${esc(a.accountNo||'—')}</td><td>${esc(T[S.lang]['act_'+a.action]||a.action)}</td><td>${esc(a.detail||'')}</td></tr>`)}
function aOverview(){const d=D();const st=[
 ['s_pending_acc',pendAcc().length],['s_pending_top',pendTop().length],['s_pending_don',pendDon().length],['s_accounts',d.accounts.filter(a=>a.status==='verified').length],
 ['s_credit',fmt(sum(d.ledger,x=>x.amount))],['s_donated',fmt(sum(d.donations,x=>x.amount))],['s_cases',d.cases.length],['s_donors',d.donors.length]];
 return `<div class="stats">${st.map(([k,v])=>`<div class="st"><b>${v}</b><span>${esc(t(k))}</span></div>`).join('')}</div>
 <div class="hd"><h3>${esc(t('recent'))}</h3></div>${d.activity.length?tbl([t('when'),t('acc_label'),t('action'),t('detail')],actRows(d.activity.slice(0,8))):empty('none_pending')}`}
function aAccounts(){const d=D(),q=String(S.adminQ||'').trim().toLowerCase();
 const accs=d.accounts.filter(a=>!q||String(a.accountNo).toLowerCase().includes(q)||String(a.name||'').toLowerCase().includes(q)).sort((a,b)=>String(b.createdAt||b.verifiedAt||'').localeCompare(String(a.createdAt||a.verifiedAt||'')));
 const pend=pendAcc().map(a=>`<div class="req"><div class="top2"><div><b dir="auto">${esc(a.name||'—')}</b> <span class="mut">· <span dir="ltr">${esc(a.phone||a.accountNo)}</span> · ${esc(t('nid'))}: <span dir="ltr">${esc(a.nid||'—')}</span> · #<span dir="ltr">${esc(a.ref||'')}</span> · ${esc(fmtDate(a.createdAt))}</span></div></div>
  <div class="acts"><a class="btn-s" href="https://wa.me/222${esc(String(a.phone||a.accountNo).replace(/\D/g,''))}" target="_blank" rel="noopener">${ic('phone',18)}<span>WhatsApp</span></a><button class="btn-s pri" data-a="acc-approve" data-id="${esc(a.id)}">${ic('check',18)}<span>${esc(t('approve'))}</span></button><button class="btn-s bad" data-a="acc-reject" data-id="${esc(a.id)}">${ic('x',18)}<span>${esc(t('reject'))}</span></button></div></div>`).join('');
 const ac=S.f.ac||{};
 const mk=`<div class="hd"><h3>${esc(t('create_acc'))}</h3></div><form class="card" data-form="acccreate" autocomplete="off"><p class="mut" style="font-size:13px">${esc(t('create_acc_hint'))}</p><div class="g2"><div>${lab('ac-p','phone')}${inp('ac-p','ac.phone',{dir:'ltr',im:'numeric',max:16})}</div><div>${lab('ac-pw','pw_label')}${inp('ac-pw','ac.pw',{dir:'ltr',max:64})}</div><div>${lab('ac-f','first_name')}${inp('ac-f','ac.first',{max:30})}</div><div>${lab('ac-l','last_name')}${inp('ac-l','ac.last',{max:30})}</div></div>${S.err&&S.adminTab==='accounts'?`<div class="alert bad" role="alert">${esc(S.err)}</div>`:''}<button class="btn" style="margin-top:12px" type="submit">${esc(t('do_create'))}</button></form>`;
 return mk+`<div class="hd"><h3>${esc(t('pend_acc'))}</h3></div>${pend||empty('none_pending')}<div class="hd"><h3>${esc(t('all_acc'))}</h3></div><div class="sbox" style="margin-top:0">${ic('search',22)}${inp('f-aq','adminQ',{r:1,ph:t('search_acc')})}</div>
 ${accs.length?tbl([t('acc_label'),t('acc_name'),t('nid'),t('status'),t('balance'),t('created'),''],accs.map(a=>`<tr><td dir="ltr" style="text-align:start"><b>${esc(a.accountNo)}</b></td><td>${esc(a.name||'—')}</td><td dir="ltr" style="text-align:start">${esc(a.nid||'—')}</td><td>${stPill(a.status)}</td><td class="num">${fmt(balanceOf(a.accountNo,d.ledger,d.donations))} MRU</td><td>${esc(fmtDate(a.createdAt||a.verifiedAt))}</td>
  <td><div class="acts"><button class="btn-s" data-a="acc-edit" data-id="${esc(a.id)}">${ic('edit',16)}</button><button class="btn-s" data-a="acc-act" data-id="${esc(a.id)}">${ic('pulse',16)}</button><button class="btn-s" data-a="acc-suspend" data-id="${esc(a.id)}">${esc(a.status==='suspended'?t('reactivate'):t('suspend'))}</button><button class="btn-s bad" data-a="acc-del" data-id="${esc(a.id)}" aria-label="${esc(t('delete'))}">${ic('trash',16)}</button></div></td></tr>`)):empty('none_pending')}`}
function aTx(){const d=D();
 const pend=pendTop().map(r=>`<div class="req"><div class="top2"><div><b dir="ltr">${esc(r.accountNo)}</b> <span class="mut">· ${esc(t('m_'+r.method))} · <span dir="ltr">${esc(r.ref)}</span> · ${esc(fmtDate(r.at))}</span></div><b class="num">${fmt(r.amount)} MRU</b></div>
  <div style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap">${r.receipt?`<img class="thumb" src="${esc(r.receipt)}" alt="" data-a="img-topup" data-id="${esc(r.id)}">`:`<span class="mut">${esc(t('no_receipt'))}</span>`}
  <div style="flex:1;min-width:140px"><label for="amt-${esc(r.id)}" style="margin-top:0">${esc(t('amount'))}</label><input id="amt-${esc(r.id)}" class="in" dir="ltr" inputmode="numeric" data-f="amt_${esc(r.id)}" value="${esc(S.f['amt_'+r.id]!=null?S.f['amt_'+r.id]:r.amount)}" autocomplete="off"></div></div>
  <div class="acts"><button class="btn-s pri" data-a="top-approve" data-id="${esc(r.id)}">${ic('check',18)}<span>${esc(t('approve'))}</span></button><button class="btn-s bad" data-a="top-reject" data-id="${esc(r.id)}">${ic('x',18)}<span>${esc(t('reject'))}</span></button></div></div>`).join('');
 const tx=S.f.tx||{};const led=d.ledger.slice().sort((a,b)=>String(b.at||'').localeCompare(String(a.at||'')));
 return `<div class="hd"><h3>${esc(t('topup_reqs'))}</h3></div>${pend?`<div class="list">${pend}</div>`:empty('none_pending')}
 <div class="hd"><h3>${esc(t('upload_tx'))}</h3></div><form class="card" data-form="tx"><p class="mut" style="font-size:13.5px">${esc(t('tx_note'))}</p>
 <div class="g2"><div>${lab('tx-acc','account_no')}${inp('tx-acc','tx.acc',{dir:'ltr',list:'acclist'})}<datalist id="acclist">${d.accounts.map(a=>`<option value="${esc(a.accountNo)}"></option>`).join('')}</datalist></div>
 <div>${lab('tx-amt','amount')}${inp('tx-amt','tx.amount',{dir:'ltr',im:'text'})}</div>
 <div>${lab('tx-m','method')}${sel('tx-m','tx.method',METHODS.concat(['cash','other']).map(m=>[m,t('m_'+m)]))}</div>
 <div>${lab('tx-ref','tx_ref')}${inp('tx-ref','tx.ref',{dir:'ltr'})}</div></div>
 ${lab('tx-note','note')}${inp('tx-note','tx.note')}
 ${lab('tx-img','image')}<input id="tx-img" class="in" type="file" accept="image/*" data-file="tx" style="padding-top:12px">${imgSrc(tx)?`<img class="pv" src="${esc(imgSrc(tx))}" alt="">`:''}
 ${S.err?`<div class="alert bad" role="alert">${esc(S.err)}</div>`:''}<button class="btn" style="margin-top:14px;max-width:260px" type="submit"${S.busy?' disabled':''}>${ic('upload',20)}<span>${esc(t('save'))}</span></button></form>
 <div class="hd"><h3>${esc(t('ledger'))}</h3></div>${led.length?tbl([t('created'),t('acc_label'),t('amount'),t('method'),t('tx_ref'),t('image'),''],led.map(x=>{const tp=x.topupId&&d.topups.find(y=>y.id===x.topupId);const src=imgSrc(x)||(tp&&tp.receipt)||'';
  return `<tr><td>${esc(fmtDate(x.at))}</td><td dir="ltr" style="text-align:start">${esc(x.accountNo)}</td><td class="amtp${x.amount<0?' neg':''}" dir="ltr">${x.amount>0?'+':'−'}${fmt(Math.abs(x.amount))}</td><td>${esc(x.method?t('m_'+x.method):'')}</td><td dir="ltr" style="text-align:start">${esc(x.ref||'')}</td>
  <td>${src?`<img class="thumb" style="width:40px;height:40px" src="${esc(src)}" alt="" data-a="img-url" data-id="${esc(x.id)}">`:'—'}</td><td><button class="btn-s bad" data-a="led-del" data-id="${esc(x.id)}" aria-label="${esc(t('delete'))}">${ic('trash',16)}</button></td></tr>`})):empty('none_pending')}`}
const caseFunds=c=>{const p=prog(c),wd=sum(D().withdrawals.filter(w=>w.caseId===c.id),w=>w.amount);return {raised:p.raised,wd,avail:p.raised-wd}};
function aCases(){const list=D().cases.slice().sort((a,b)=>String(b.createdAt||'').localeCompare(String(a.createdAt||'')));
 return `<div class="hd"><h3>${esc(t('tab_cases'))}</h3><button class="btn-s pri" data-a="case-new">${ic('plus',18)}<span>${esc(t('new_case'))}</span></button></div>
 ${list.length?tbl([t('title_ar'),t('category'),t('raised'),t('goal'),t('acct_avail'),t('deadline'),''],list.map(c=>{const p=prog(c),f=caseFunds(c);return `<tr><td><b>${esc(loc(c.title))}</b><div class="mut" style="font-size:12.5px">${esc(loc(c.location))}</div></td><td>${pill(c.category==='urgent'?'hot':'',t('cat_'+c.category))}</td><td class="num">${fmt(p.raised)}</td><td class="num">${fmt(p.goal)}</td><td class="num"><b>${fmt(f.avail)}</b></td><td>${esc(c.deadline||'—')}</td>
  <td><div class="acts"><button class="btn-s pri" data-a="case-acct" data-id="${esc(c.id)}">${ic('wallet',16)}<span>${esc(t('case_acct'))}</span></button><button class="btn-s" data-a="case-edit" data-id="${esc(c.id)}">${ic('edit',16)}</button><button class="btn-s bad" data-a="case-del" data-id="${esc(c.id)}" aria-label="${esc(t('delete'))}">${ic('trash',16)}</button></div></td></tr>`})):empty('no_cases')}`}
function aBlood(){const list=(D().blood_searches||[]).slice().sort((a,b)=>(a.status==='open'?0:1)-(b.status==='open'?0:1)||String(b.at).localeCompare(String(a.at)));
 return `<div class="hd"><h3>${esc(t('bs_reqs'))}</h3></div>${list.length?list.map(r=>`<div class="req"><div class="top2"><div><b>${esc(r.hospital)}</b> <span class="mut">· ${esc(wname(r.wilaya))} · ${esc(t('bs_contact'))}: <span dir="ltr">+${/^\d{8}$/.test(r.accountNo)?'222 ':''}${esc(r.accountNo)}</span> · ${esc(fmtDate(r.at))}</span></div>${bd(r.bloodType||'')}</div>
 <div class="acts">${bsBadge(r.status)}${['open','found','closed'].filter(x=>x!==r.status).map(x=>`<button class="btn-s${x==='found'?' pri':''}" data-a="bs-status" data-id="${esc(r.id)}" data-st="${x}">${esc(t('bs_set_'+x))}</button>`).join('')}</div></div>`).join(''):empty('bs_none')}`}
function aDonors(){const pend=pendDon().map(r=>`<div class="req"><div class="top2"><div><b>${esc(r.name)}</b> <span class="mut">· ${esc(r.city||'')} · <span dir="ltr">+222 ${esc(r.phone)}</span> · <span dir="ltr">${esc(r.accountNo)}</span></span></div>${bd(r.bloodType||'')}</div>
  <div class="acts"><button class="btn-s pri" data-a="don-approve" data-id="${esc(r.id)}">${ic('check',18)}<span>${esc(t('approve'))}</span></button><button class="btn-s bad" data-a="don-reject" data-id="${esc(r.id)}">${ic('x',18)}<span>${esc(t('reject'))}</span></button></div></div>`).join('');
 const list=D().donors.slice().sort((a,b)=>String(b.verifiedAt||'').localeCompare(String(a.verifiedAt||'')));
 return `<div class="hd"><h3>${esc(t('donor_reqs'))}</h3></div>${pend?`<div class="list">${pend}</div>`:empty('none_pending')}
 <div class="hd"><h3>${esc(t('all_donors'))}</h3><button class="btn-s pri" data-a="don-new">${ic('plus',18)}<span>${esc(t('add_donor'))}</span></button></div>
 ${list.length?tbl([t('full_name'),t('blood_type'),t('city'),t('phone'),''],list.map(d=>`<tr><td><b>${esc(d.name)}</b></td><td>${bd(d.bloodType||'')}</td><td>${esc(d.city||'')}</td><td dir="ltr" style="text-align:start">+222 ${esc(d.phone)}</td><td><div class="acts"><button class="btn-s" data-a="don-edit" data-id="${esc(d.id)}">${ic('edit',16)}</button><button class="btn-s bad" data-a="don-del" data-id="${esc(d.id)}" aria-label="${esc(t('delete'))}">${ic('trash',16)}</button></div></td></tr>`)):empty('no_donors')}`}
function aCharities(){const list=D().charities;
 return `<div class="hd"><h3>${esc(t('tab_charities'))}</h3><button class="btn-s pri" data-a="ch-new">${ic('plus',18)}<span>${esc(t('new_charity'))}</span></button></div>
 ${list.length?tbl([t('ch_name_ar'),'',''],list.map(c=>`<tr><td><b>${esc(loc(c.name))}</b><div class="mut" style="font-size:12.5px">${esc(loc(c.desc))}</div></td><td>${c.verified!==false?pill('',t('verified_badge')):''}</td><td><div class="acts"><button class="btn-s" data-a="ch-edit" data-id="${esc(c.id)}">${ic('edit',16)}</button><button class="btn-s bad" data-a="ch-del" data-id="${esc(c.id)}" aria-label="${esc(t('delete'))}">${ic('trash',16)}</button></div></td></tr>`)):empty('no_ch')}`}
function aActivity(){const q=String(S.adminQ||'').trim().toLowerCase();const list=D().activity.filter(a=>!q||String(a.accountNo||'').toLowerCase().includes(q));
 return `<div class="hd"><h3>${esc(t('user_activity'))}</h3><button class="btn-s" data-a="prune">${ic('trash',16)}<span>${esc(t('prune'))}</span></button></div>
 <div class="sbox" style="margin-top:0">${ic('search',22)}${inp('f-aq2','adminQ',{r:1,dir:'ltr',ph:t('filter_acc')})}</div>
 ${list.length?tbl([t('when'),t('acc_label'),t('action'),t('detail')],actRows(list)):empty('none_pending')}`}
const ymd=v=>{const x=new Date(v);return x.getFullYear()+'-'+String(x.getMonth()+1).padStart(2,'0')+'-'+String(x.getDate()).padStart(2,'0')};
function repStats(match){const d=D();const inR=v=>v&&match(ymd(v));
 const led=d.ledger.filter(x=>inR(x.at)),don=d.donations.filter(x=>inR(x.at)),act=d.activity.filter(x=>inR(x.at)),tops=d.topups.filter(x=>inR(x.at));
 const sess=act.filter(a=>a.action==='login'||a.action==='register');
 const byCase={};don.filter(x=>x.caseId).forEach(x=>{byCase[x.caseId]=(byCase[x.caseId]||0)+(Number(x.amount)||0)});
 return {newAcc:d.accounts.filter(a=>inR(a.createdAt)).length,ver:d.accounts.filter(a=>inR(a.verifiedAt)&&a.verifiedAt!==a.createdAt).length+0,logins:sess.length,active:new Set(act.filter(a=>a.by!=='admin'&&a.accountNo).map(a=>a.accountNo)).size,
  topReq:tops.length,topOk:sum(led.filter(x=>x.source==='topup'),x=>x.amount),manual:sum(led.filter(x=>x.source==='admin'),x=>x.amount),
  donN:don.length,donAmt:sum(don,x=>x.amount),donCases:sum(don.filter(x=>x.caseId),x=>x.amount),donCh:sum(don.filter(x=>x.charityId),x=>x.amount),
  donors:d.donor_requests.filter(x=>inR(x.at)).length,wd:sum(d.withdrawals.filter(x=>inR(x.at)),x=>x.amount),byCase}}
function repTiles(r){const rows=[['r_new_acc',r.newAcc],['r_verified',r.ver],['r_logins',r.logins],['r_active',r.active],['r_top_req',r.topReq],['r_top_ok',fmt(r.topOk)],['r_manual',fmt(r.manual)],['r_don_n',r.donN],['r_don_amt',fmt(r.donAmt)],['r_don_cases',fmt(r.donCases)],['r_don_ch',fmt(r.donCh)],['r_donors',r.donors],['r_wd',fmt(r.wd)]];
 return `<div class="stats">${rows.map(([k,v])=>`<div class="st"><b>${v}</b><span>${esc(t(k))}</span></div>`).join('')}</div>`}
function aReports(){const today=ymd(Date.now());if(!S.f.rep)S.f.rep={day:today,month:today.slice(0,7)};const rp=S.f.rep;
 const day=/^\d{4}-\d{2}-\d{2}$/.test(rp.day||'')?rp.day:today,mon=/^\d{4}-\d{2}$/.test(rp.month||'')?rp.month:today.slice(0,7);
 const dr=repStats(d=>d===day),mr=repStats(d=>d.slice(0,7)===mon);
 const [yy,mm]=mon.split('-').map(Number),days=new Date(yy,mm,0).getDate(),rows=[];
 for(let i=1;i<=days;i++){const key=mon+'-'+String(i).padStart(2,'0');const s=repStats(d=>d===key);if(s.newAcc||s.logins||s.topOk||s.manual||s.donN)rows.push(`<tr><td class="num">${key}</td><td class="num">${s.newAcc}</td><td class="num">${s.logins}</td><td class="num">${fmt(s.topOk+s.manual)}</td><td class="num">${s.donN}</td><td class="num">${fmt(s.donAmt)}</td></tr>`)}
 const top=Object.keys(mr.byCase).sort((a,b)=>mr.byCase[b]-mr.byCase[a]).slice(0,5).map(id=>{const c=D().cases.find(x=>x.id===id);return `<tr><td>${esc(c?loc(c.title):id)}</td><td class="num">${fmt(mr.byCase[id])} MRU</td></tr>`});
 return `<div class="hd"><h3>${esc(t('r_day'))}</h3><button class="btn-s" data-a="print">${esc(t('print'))}</button></div>
 <div class="card" style="margin-bottom:12px"><label for="rep-d" style="margin-top:0">${esc(t('r_pick_day'))}</label>${inp('rep-d','rep.day',{type:'date',dir:'ltr',r:1})}</div>${repTiles(dr)}
 <div class="hd" style="margin-top:20px"><h3>${esc(t('r_month'))}</h3></div>
 <div class="card" style="margin-bottom:12px"><label for="rep-m" style="margin-top:0">${esc(t('r_pick_month'))}</label>${inp('rep-m','rep.month',{type:'month',dir:'ltr',r:1})}</div>${repTiles(mr)}
 <div class="hd" style="margin-top:20px"><h3>${esc(t('r_by_day'))}</h3></div>${rows.length?tbl([t('r_day_col'),t('r_new_acc'),t('r_logins'),t('tx_topup')+' + '+t('tx_adjust'),t('r_don_n'),t('r_don_amt')],rows):empty('r_none')}
 ${top.length?`<div class="hd" style="margin-top:20px"><h3>${esc(t('r_top_cases'))}</h3></div>${tbl([t('case'),t('amount')],top)}`:''}`}
function pwCard(tabName){const pw=S.f.pw||{};return `<form class="card" data-form="password" style="max-width:560px;margin-top:16px" autocomplete="off"><h4 style="font-weight:800">${esc(t('pw_title'))}</h4>
 ${lab('pw-cur','pw_cur')}${inp('pw-cur','pw.cur',{dir:'ltr',type:'password'})}${lab('pw-new','pw_new')}${inp('pw-new','pw.next',{dir:'ltr',type:'password'})}${lab('pw-again','pw_again')}${inp('pw-again','pw.again',{dir:'ltr',type:'password'})}
 ${S.err&&S.adminTab===tabName?`<div class="alert bad" role="alert">${esc(S.err)}</div>`:''}<button class="btn" style="margin-top:18px" type="submit">${esc(t('save'))}</button></form>`}
function aSecurity(){return `<div class="hd"><h3>${esc(t('tab_security'))}</h3></div>${pwCard('security')}`}
function aSettings(){const pw=S.f.pw||{};return `<div class="hd"><h3>${esc(t('settings_title'))}</h3></div><form class="card" data-form="settings" style="max-width:560px">
  ${lab('s-wa','s_wa')}${inp('s-wa','st.whatsapp',{dir:'ltr',im:'numeric',max:15})}
  <h4 style="margin-top:18px;font-weight:800">${esc(t('pay_numbers'))}</h4>
 ${METHODS.map(m=>lab('s-'+m,'m_'+m)+inp('s-'+m,'st.'+m,{dir:'ltr',im:'numeric',max:20})).join('')}
 ${lab('s-bar','s_blood_ar')}${area('s-bar','st.bloodAr')}${lab('s-ben','s_blood_en')}${area('s-ben','st.bloodEn')}
 <button class="btn" style="margin-top:18px" type="submit">${esc(t('save'))}</button></form>
 ${pwCard('settings')}`}

/* admin modals */
function adminModal(m){
 if(m.type==='case'){return `<h3>${esc(t(m.id?'edit_case':'new_case'))}</h3><div class="g2"><div>${lab('c-ta','title_ar')}${inp('c-ta','cf.title_ar')}</div><div>${lab('c-te','title_en')}${inp('c-te','cf.title_en',{dir:'ltr'})}</div>
  <div>${lab('c-la','loc_ar')}${inp('c-la','cf.loc_ar')}</div><div>${lab('c-le','loc_en')}${inp('c-le','cf.loc_en',{dir:'ltr'})}</div></div>
  ${lab('c-sa','story_ar')}${area('c-sa','cf.story_ar')}${lab('c-se','story_en')}${area('c-se','cf.story_en')}
  <div class="g2"><div>${lab('c-g','goal_amt')}${inp('c-g','cf.goal',{dir:'ltr',im:'numeric'})}</div><div>${lab('c-br','base_raised')}${inp('c-br','cf.baseRaised',{dir:'ltr',im:'numeric'})}</div>
  <div>${lab('c-bd','base_donors')}${inp('c-bd','cf.baseDonors',{dir:'ltr',im:'numeric'})}</div><div>${lab('c-dl','deadline')}${inp('c-dl','cf.deadline',{type:'date',dir:'ltr'})}</div></div>
  ${lab('c-cat','category')}${sel('c-cat','cf.category',CATS.map(c=>[c,t('cat_'+c)]))}
  ${lab('c-sec','case_secret')}${inp('c-sec','cf.secret',{dir:'ltr',max:12,ph:m.id?t('secret_hint'):''})}
  ${lab('c-img','image')}<input id="c-img" class="in" type="file" accept="image/*" data-file="case" style="padding-top:12px">${imgSrc(S.f.cf)?`<img class="pv" src="${esc(imgSrc(S.f.cf))}" alt="">`:''}
  ${S.err?`<div class="alert bad" role="alert">${esc(S.err)}</div>`:''}<div class="foot"><button class="btn o" data-a="close">${esc(t('cancel'))}</button><button class="btn" data-a="case-save"${S.busy?' disabled':''}>${esc(t('save'))}</button></div>`}
 if(m.type==='caseacct'){const c=byId('cases',m.id);if(!c)return '';const f=caseFunds(c),wf=S.f.wd||{},wds=D().withdrawals.filter(w=>w.caseId===c.id).slice().reverse(),dons=D().donations.filter(x=>x.caseId===c.id).slice().reverse();
  return `<h3>${esc(t('case_report'))} · ${esc(loc(c.title))}</h3>
  <div class="stats"><div class="st"><b>${fmt(f.raised)}</b><span>${esc(t('acct_raised'))}</span></div><div class="st"><b>${fmt(f.wd)}</b><span>${esc(t('acct_withdrawn'))}</span></div><div class="st"><b>${fmt(f.avail)}</b><span>${esc(t('acct_avail'))}</span></div><div class="st"><b>${dons.length}</b><span>${esc(t('acct_donors'))}</span></div></div>
  <form class="card noprint" data-form="none" style="margin-top:12px"><h4 style="font-weight:800">${esc(t('wd_title'))}</h4>${lab('w-sec','wd_secret')}<div class="field">${ic('lock')}${inp('w-sec','wd.secret',{dir:'ltr',max:12,type:'password'})}</div>${lab('w-amt','wd_amount')}${inp('w-amt','wd.amount',{dir:'ltr',im:'numeric'})}${lab('w-pay','wd_payee')}${inp('w-pay','wd.payee',{max:80})}${lab('w-pur','wd_purpose')}${inp('w-pur','wd.purpose',{max:200})}
  ${S.err?`<div class="alert bad" role="alert">${esc(S.err)}</div>`:''}<button type="button" class="btn" style="margin-top:12px" data-a="wd-go"${S.busy||!c.hasSecret?' disabled':''}>${esc(t('wd_btn'))}</button>${c.hasSecret?'':`<div class="alert warn">${esc(t('err_nosecret'))}</div>`}</form>
  <h4 style="margin-top:16px;font-weight:800">${esc(t('wd_list'))}</h4>${wds.length?tbl([t('inv_no'),t('inv_date'),t('inv_payee'),t('amount'),''],wds.map(w=>`<tr><td dir="ltr">${esc(w.no)}</td><td class="num">${esc(fmtDate(w.at))}</td><td>${esc(w.payee)}</td><td class="num">${fmt(w.amount)}</td><td><button type="button" class="btn-s" data-a="inv-open" data-id="${esc(w.id)}">${esc(t('view_invoice'))}</button></td></tr>`)):empty('none_pending')}
  <h4 style="margin-top:16px;font-weight:800">${esc(t('acct_donors'))}</h4>${dons.length?tbl([t('inv_date'),t('acc_label'),t('amount')],dons.slice(0,60).map(x=>`<tr><td class="num">${esc(fmtDate(x.at))}</td><td dir="ltr" style="text-align:start">${esc(x.accountNo)}</td><td class="num">${fmt(x.amount)}</td></tr>`)):empty('none_pending')}
  <div class="foot noprint"><button type="button" class="btn o" data-a="close">${esc(t('close'))}</button><button type="button" class="btn" data-a="print-modal">${esc(t('print'))}</button></div>`}
 if(m.type==='invoice'){const w=byId('withdrawals',m.id);if(!w)return '';return `<div class="inv"><div class="inv-h"><span class="lg geo">${logo('lgi',34)}</span><div><b style="font-size:20px">${esc(t('appName'))}</b><div class="mut">Dar El Kheir</div></div></div>
  <h2 class="inv-t">${esc(t('inv_title'))}</h2>
  <div class="kv"><span class="mut">${esc(t('inv_no'))}</span><b dir="ltr">${esc(w.no)}</b></div><div class="kv"><span class="mut">${esc(t('inv_date'))}</span><b class="num">${esc(fmtDate(w.at))}</b></div>
  <div class="kv"><span class="mut">${esc(t('inv_case'))}</span><b>${esc(loc(w.caseTitle))}</b></div><div class="kv"><span class="mut">${esc(t('inv_payee'))}</span><b>${esc(w.payee)}</b></div>
  ${w.purpose?`<div class="kv"><span class="mut">${esc(t('inv_purpose'))}</span><b>${esc(w.purpose)}</b></div>`:''}
  <div class="inv-amt" dir="ltr">− ${fmt(w.amount)} MRU</div>
  <div class="inv-sig"><div><div class="mut">${esc(t('inv_manager'))}</div><div class="sig" dir="ltr">${esc(w.signedBy)}</div><div style="font-weight:700;margin-top:4px" dir="ltr">${esc(w.signedBy)}</div></div><div class="stamp">${esc(t('inv_signed'))}</div></div></div>
  <div class="foot noprint"><button type="button" class="btn o" data-a="close">${esc(t('close'))}</button><button type="button" class="btn" data-a="print-modal">${esc(t('print'))}</button></div>`}
 if(m.type==='charity'){return `<h3>${esc(t(m.id?'edit_charity':'new_charity'))}</h3><div class="g2"><div>${lab('h-na','ch_name_ar')}${inp('h-na','hf.name_ar')}</div><div>${lab('h-ne','ch_name_en')}${inp('h-ne','hf.name_en',{dir:'ltr'})}</div>
  <div>${lab('h-da','ch_desc_ar')}${area('h-da','hf.desc_ar',2)}</div><div>${lab('h-de','ch_desc_en')}${area('h-de','hf.desc_en',2)}</div></div>
  ${lab('h-ic','icon')}${sel('h-ic','hf.icon',[['heart',t('i_heart')],['building',t('i_building')],['water',t('i_water')],['drop',t('i_drop')]])}
  <div class="foot"><button class="btn o" data-a="close">${esc(t('cancel'))}</button><button class="btn" data-a="ch-save">${esc(t('save'))}</button></div>`}
 if(m.type==='donorEdit'){return `<h3>${esc(t(m.id?'edit_donor':'add_donor'))}</h3>${lab('e-name','full_name')}${inp('e-name','de.name')}${lab('e-type','blood_type')}${sel('e-type','de.type',BLOOD.map(b=>[b,b.replace('-','−')]))}
  ${lab('e-city','city')}${inp('e-city','de.city')}${lab('e-phone','phone')}${inp('e-phone','de.phone',{dir:'ltr',im:'numeric',max:12})}
  ${S.err?`<div class="alert bad" role="alert">${esc(S.err)}</div>`:''}<div class="foot"><button class="btn o" data-a="close">${esc(t('cancel'))}</button><button class="btn" data-a="don-save">${esc(t('save'))}</button></div>`}
 if(m.type==='account'){return `<h3>${esc(t('edit'))} · <span dir="ltr">${esc(m.id)}</span></h3>${lab('a-name','acc_name')}${inp('a-name','an.name')}<div class="foot"><button class="btn o" data-a="close">${esc(t('cancel'))}</button><button class="btn" data-a="acc-save">${esc(t('save'))}</button></div>`}
 return ''}

/* admin actions */
const byId=(k,id)=>S.D[k].find(x=>x.id===id);
async function adm(type,data){return run(async()=>{await api('/api/action',Object.assign({type},data||{}));await poll(true);toast(t('done'))})}
async function accCreate(){const f=S.f.ac||{};S.err='';
 try{await api('/api/action',{type:'account_create',phone:f.phone||'',first:f.first||'',last:f.last||'',password:f.pw||''});S.f.ac={};await poll(true);toast(t('done'))}catch(e){S.err=errMsg(e)}
 sched()}
const accApprove=id=>adm('account_approve',{acc:id});
const accReject=id=>adm('account_reject',{acc:id});
const accSuspend=id=>adm('account_suspend',{acc:id});
function topApprove(id){const r=byId('topups',id);if(!r)return;const amt=Math.floor(num(S.f['amt_'+id]!=null?S.f['amt_'+id]:r.amount));if(!(amt>0))return toast(t('err_amount'));return adm('topup_approve',{id,amount:amt})}
const topReject=id=>adm('topup_reject',{id});
async function txSave(){const f=S.f.tx||{};const acc=String(f.acc||'').trim(),amt=Math.round(num(f.amount));S.err='';
 if(!S.D.accounts.some(a=>a.accountNo===acc)){S.err=t('err_noacc');return sched()}
 if(!amt){S.err=t('err_amount');return sched()}
 S.busy=true;sched();
 const ok=await adm('tx_add',{acc,amount:amt,method:f.method||'bankily',ref:String(f.ref||'').trim(),note:String(f.note||'').trim(),image:f.image||''});
 if(ok)S.f.tx={method:'bankily'};S.busy=false;sched()}
function caseForm(c){return {title_ar:c&&c.title?c.title.ar||'':'',title_en:c&&c.title?c.title.en||'':'',loc_ar:c&&c.location?c.location.ar||'':'',loc_en:c&&c.location?c.location.en||'':'',story_ar:c&&c.story?c.story.ar||'':'',story_en:c&&c.story?c.story.en||'':'',
 goal:c?String(c.goal||''):'',baseRaised:c?String(c.baseRaised||0):'0',baseDonors:c?String(c.baseDonors||0):'0',deadline:c?c.deadline||'':'',category:c?c.category||'active':'urgent',image:c?c.image||'':'',secret:c?'':'2324'}}
async function caseSave(){const f=S.f.cf;S.err='';if(!String(f.title_ar||'').trim()&&!String(f.title_en||'').trim()){S.err=t('err_title');return sched()}
 const goal=Math.round(num(f.goal));if(!(goal>0)){S.err=t('err_goal');return sched()}
 S.busy=true;sched();
 const ok=await adm('case_save',{id:S.modal.id||'',data:{title_ar:f.title_ar,title_en:f.title_en,loc_ar:f.loc_ar,loc_en:f.loc_en,story_ar:f.story_ar,story_en:f.story_en,goal,baseRaised:Math.round(num(f.baseRaised)),baseDonors:Math.round(num(f.baseDonors)),deadline:f.deadline||'',category:f.category||'active',image:f.image||'',secret:String(f.secret||'').trim()}});
 if(ok)S.modal=null;S.busy=false;sched()}
async function withdrawFunds(){const f=S.f.wd||{},cid=S.modal.id,amt=Math.floor(num(f.amount));S.err='';
 if(!String(f.secret||'').trim()){S.err=t('err_secret');return sched()}
 if(!(amt>0)){S.err=t('err_amount');return sched()}
 if(!String(f.payee||'').trim()){S.err=t('err_name');return sched()}
 S.busy=true;sched();
 try{const r=await api('/api/action',{type:'withdraw',caseId:cid,secret:String(f.secret),amount:amt,payee:String(f.payee).trim(),purpose:String(f.purpose||'').trim()});await poll(true);S.f.wd=null;S.modal={type:'invoice',id:r.id}}catch(e){S.err=errMsg(e)}
 S.busy=false;sched()}
const donApprove=id=>adm('donor_approve',{acc:id});
const donReject=id=>adm('donor_reject',{acc:id});
async function donSave(){const f=S.f.de||{};S.err='';const phone=digits(f.phone||'').replace(/\D/g,'').replace(/^222/,'');
 if(!String(f.name||'').trim()){S.err=t('err_name');return sched()}if(!/^\d{8}$/.test(phone)){S.err=t('err_phone');return sched()}
 const ok=await adm('donor_save',{id:S.modal.id||'',name:String(f.name).trim(),bloodType:f.type||'O+',city:String(f.city||'').trim(),phone});
 if(ok)S.modal=null;sched()}
async function chSave(){const f=S.f.hf||{};if(!String(f.name_ar||'').trim()&&!String(f.name_en||'').trim())return toast(t('err_name'));
 const ok=await adm('charity_save',{id:S.modal.id||'',name_ar:f.name_ar||'',name_en:f.name_en||'',desc_ar:f.desc_ar||'',desc_en:f.desc_en||'',icon:f.icon||'heart'});
 if(ok)S.modal=null;sched()}
async function settingsSave(){const f=S.f.st||{};await adm('settings_save',{whatsapp:f.whatsapp||'',bankily:f.bankily||'',masrvi:f.masrvi||'',sedad:f.sedad||'',bloodAr:f.bloodAr||'',bloodEn:f.bloodEn||''})}
const prune=()=>adm('prune');
function delDoc(path){const p=String(path).split('/');return adm('delete_doc',{col:p[0],id:p[1]})}

/* ---------- events ---------- */
function act(a,el){const id=el.dataset.id;
 if(a==='go'&&(ISPANEL||el.dataset.v==='admin'))return;
 switch(a){
 case 'go':S.view=el.dataset.v;S.err='';S.modal=null;S.q='';S.chq='';S.adminQ='';S.f=S.view==='wallet'?S.f:{};window.scrollTo(0,0);break;
 case 'lang':S.lang=S.lang==='ar'?'en':'ar';ls.set('dek_lang',S.lang);break;
 case 'auth-mode':S.authMode=el.dataset.m;S.err='';S.f={};break;
 case 'wa':openWA();return;
 case 'notif-on':try{Notification.requestPermission().then(()=>sched())}catch(e){}return;
 case 'notif-check':break;
 case 'toggle-code':S.showCode=!S.showCode;break;
 case 'logout':logout();return;
 case 'admin-logout':adminLogout();return;
 case 'cases-f':S.casesFilter=el.dataset.f2;S.view='cases';window.scrollTo(0,0);break;
 case 'case':S.caseId=id;S.view='case';S.err='';S.f={};window.scrollTo(0,0);break;
 case 'amt':S.f.donate=el.dataset.n;break;
 case 'donate':donate();return;
 case 'ch-donate':S.f.donate='';S.err='';S.modal={type:'chdonate',id};break;
 case 'ch-donate-go':donateCharity();return;
 case 'ch-topup':S.modal=null;S.view='wallet';window.scrollTo(0,0);break;
 case 'photo-rm':S.f.pf.photo='';S.f.pf.rm=true;break;
 case 'print':window.print();return;
 case 'print-modal':document.body.classList.add('print-modal');try{window.print()}finally{document.body.classList.remove('print-modal')}return;
 case 'case-acct':S.f.wd={secret:'',amount:'',payee:'',purpose:''};S.err='';S.modal={type:'caseacct',id};break;
 case 'wd-go':withdrawFunds();return;
 case 'inv-open':S.modal={type:'invoice',id};break;
 case 'topup-method':S.f.t_method=el.dataset.m;S.view='wallet';S.err='';window.scrollTo(0,0);break;
 case 'blood-f':S.bloodFilter=el.dataset.f2;break;
 case 'reveal':revealPhone(id);return;
 case 'donor-open':S.f.dn={name:'',type:'O+',city:'',phone:''};S.err='';S.modal={type:'donor'};break;
 case 'donor-save':submitDonor();return;
 case 'bs-send':submitBS();return;
 case 'bs-status':adm('blood_search_status',{id:id,status:el.dataset.st});return;
 case 'close':S.modal=null;S.err='';break;
 case 'confirm-yes':{const cb=S.modal&&S.modal.cb;S.modal=null;if(cb)cb();break}
 case 'img-topup':{const r=byId('topups',id);if(r&&r.receipt)S.modal={type:'img',src:r.receipt};break}
 case 'img-url':{const r=byId('ledger',id);const tp=r&&r.topupId&&byId('topups',r.topupId);const s=imgSrc(r)||(tp&&tp.receipt)||'';if(s)S.modal={type:'img',src:s};break}
 case 'atab':S.adminTab=el.dataset.k;S.adminQ='';S.f.adminQ='';S.err='';break;
 case 'acc-approve':accApprove(id);return;
 case 'acc-reject':accReject(id);return;
 case 'acc-suspend':accSuspend(id);return;
 case 'acc-del':ask(()=>adm('account_delete',{acc:id}));return;
 case 'acc-edit':{const a=byId('accounts',id);S.f.an={name:a&&a.name||''};S.modal={type:'account',id};break}
 case 'acc-save':adm('account_edit',{acc:S.modal.id,name:String(S.f.an.name||'').trim()}).then(ok=>{if(ok)S.modal=null;sched()});return;
 case 'acc-act':S.adminTab='activity';S.adminQ=byId('accounts',id).accountNo;S.f.adminQ=S.adminQ;break;
 case 'top-approve':topApprove(id);return;
 case 'top-reject':topReject(id);return;
 case 'led-del':ask(()=>delDoc('ledger/'+id));return;
 case 'case-new':S.f.cf=caseForm(null);S.err='';S.modal={type:'case',id:null};break;
 case 'case-edit':S.f.cf=caseForm(byId('cases',id));S.err='';S.modal={type:'case',id};break;
 case 'case-save':caseSave();return;
 case 'case-del':ask(()=>delDoc('cases/'+id));return;
 case 'don-approve':donApprove(id);return;
 case 'don-reject':donReject(id);return;
 case 'don-new':S.f.de={name:'',type:'O+',city:'',phone:''};S.err='';S.modal={type:'donorEdit',id:null};break;
 case 'don-edit':{const d=byId('donors',id);S.f.de={name:d.name,type:d.bloodType,city:d.city||'',phone:d.phone};S.err='';S.modal={type:'donorEdit',id};break}
 case 'don-save':donSave();return;
 case 'don-del':ask(()=>delDoc('donors/'+id));return;
 case 'ch-new':S.f.hf={name_ar:'',name_en:'',desc_ar:'',desc_en:'',icon:'heart'};S.modal={type:'charity',id:null};break;
 case 'ch-edit':{const c=byId('charities',id);S.f.hf={name_ar:(c.name||{}).ar||'',name_en:(c.name||{}).en||'',desc_ar:(c.desc||{}).ar||'',desc_en:(c.desc||{}).en||'',icon:c.icon||'heart'};S.modal={type:'charity',id};break}
 case 'ch-save':chSave();return;
 case 'ch-del':ask(()=>delDoc('charities/'+id));return;
 case 'prune':ask(prune);return;
 }
 if(S.view==='admin'&&S.adminTab==='settings'&&!S.f.st)loadSettingsForm();
 sched()}
function loadSettingsForm(){const s=S.D.settings.find(x=>x.id==='main')||{};S.f.st={whatsapp:s.whatsapp||WA_DEFAULT,bankily:s.bankily||'',masrvi:s.masrvi||'',sedad:s.sedad||'',bloodAr:s.bloodAr||'',bloodEn:s.bloodEn||''}}
root.addEventListener('click',e=>{
 if(e.target.dataset&&e.target.dataset.ovl){S.modal=null;S.err='';sched();return}
 const b=e.target.closest('[data-a]');if(!b)return;e.preventDefault();act(b.dataset.a,b)});
root.addEventListener('input',e=>{const el=e.target;
 if(el.dataset.chk){const id=el.dataset.chk,v=digits(el.value).trim();S.f['chkv_'+id]=v;clearTimeout(chkT);
  if(v.length<4){S.f['chk_'+id]='';sched();return}
  chkT=setTimeout(()=>{api('/api/action',{type:'check_code',acc:id,code:v}).then(r=>{S.f['chk_'+id]=r.ok?'ok':'bad';sched()}).catch(()=>{})},300);return}
 const p=el.dataset.f;if(!p)return;sp(S.f,p,el.type==='checkbox'?el.checked:el.value);
 if(p==='q')S.q=el.value;if(p==='chq')S.chq=el.value;if(p==='adminQ')S.adminQ=el.value;
 if(el.dataset.r)sched()});
root.addEventListener('change',e=>{const el=e.target;if(el.dataset.file){onFile(el.dataset.file,el.files&&el.files[0])}
 else if(el.dataset.f&&el.tagName==='SELECT'){sp(S.f,el.dataset.f,el.value);if(el.dataset.f==='t_method')sched()}});
root.addEventListener('submit',e=>{e.preventDefault();const f=e.target.dataset.form;
 if(f==='login')doLogin();else if(f==='topup')submitTopup();else if(f==='register')doRegister();else if(f==='profile')saveProfile();else if(f==='tx')txSave();else if(f==='acccreate')accCreate();else if(f==='settings')settingsSave();else if(f==='adminlogin')adminLogin();else if(f==='password')pwSave()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&S.modal){S.modal=null;S.err='';sched()}});

/* ---------- boot ---------- */
function boot(){
 S.lang=ls.get('dek_lang')==='en'?'en':'ar';
 S.codePlain=ss.get('dek_pcode')||'';
 if(ISPANEL)S.view='admin';
 sched();poll(true);
 setInterval(()=>poll(),5000);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden){poll();sched()}});window.addEventListener('focus',()=>sched());
 if(PAGE==='site'&&'serviceWorker' in navigator)navigator.serviceWorker.register('/sw.js').catch(()=>{});
}
boot();
})();
