دار الخير | Dar El Kheir
(الدخول مباشر: أي رقم حساب جديد مع رمز من 4 إلى 8 أرقام يُنشئ حسابًا فورًا بلا توثيق)

1) ثبّت Node.js من https://nodejs.org (نسخة LTS).
2) ويندوز: اضغط مرتين على start-windows.bat   |   ماك: start-mac.command   |   أو الأمر: node server.js
3) الموقع:        http://localhost:3000
   لوحة التحكم:  http://localhost:3000/admin
4) لوحة التحكم تفتح بدون كلمة مرور على هذا الجهاز فقط.
   عند نشر الموقع على الإنترنت تُطلب كلمة مرور تلقائيًا: node server.js set-password "كلمة-8-أحرف-أو-أكثر"

Files: index.html (site) | admin.html (control panel) | app.js | styles.css | server.js
Data is stored in the "data" folder created on first run. Back it up.
Env: PORT, DATA_DIR, ADMIN_PASSWORD (first run only), COOKIE_SECURE=1, TRUST_PROXY=1 (behind a proxy).
For public use: host on a Node server with HTTPS and a persistent "data" folder.


النشر على الإنترنت: شغّل node server.js set-password "كلمة-مرور-قوية" ثم ضع الموقع خلف HTTPS (Caddy/nginx) مع TRUST_PROXY=1 و COOKIE_SECURE=1.
لوحة التحكم بلا كلمة مرور على نفس الجهاز فقط (localhost).

ثلاث لوحات تحكم: /admin (الحسابات والمتبرعون والتقارير والإعدادات)، /manage (الحالات والجمعيات وسحب الأموال)، /topups (شحن الأموال فقط).
على الإنترنت لكل لوحة كلمة مرور خاصة: node server.js set-password admin "..." ثم manage ثم topups.
تسجيل دخول المستخدم برقم الهاتف (+222). المقيمون خارج الوطن يتواصلون عبر واتساب، والمدير ينشئ حسابهم من لوحة /admin ← الحسابات.
