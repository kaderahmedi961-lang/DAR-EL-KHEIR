#!/usr/bin/env node
'use strict';
/* Dar El Kheir server. No dependencies, Node 18+.
   Storage: JSON file + image folders under ./data. All permissions are enforced here. */
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '0.0.0.0';
const ROOT = __dirname;
/* Works with the normal layout (public/ folder) and also if index.html, app.js and styles.css sit next to server.js. */
const FLAT = !fs.existsSync(path.join(ROOT, 'public', 'index.html'));
const PUB = FLAT ? ROOT : path.join(ROOT, 'public');
const FLAT_FILES = new Set(['index.html', 'admin.html', 'manage.html', 'topups.html', 'app.js', 'styles.css', 'sw.js', 'manifest.webmanifest', 'logo.png', 'logo-mark.png', 'icon-192.png', 'icon-512.png', 'apple-touch-icon.png']);
const INDEX = path.join(PUB, 'index.html');
const DATA = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(ROOT, 'data');
const FILE_DB = path.join(DATA, 'db.json'), FILE_CFG = path.join(DATA, 'config.json');
const UP_PUB = path.join(DATA, 'uploads', 'public'), UP_PRIV = path.join(DATA, 'uploads', 'private');
fs.mkdirSync(UP_PUB, { recursive: true, mode: 0o700 });
fs.mkdirSync(UP_PRIV, { recursive: true, mode: 0o700 });
try { fs.chmodSync(DATA, 0o700); } catch (e) {}

const METHODS = ['bankily', 'masrvi', 'sedad'];
const TX_METHODS = METHODS.concat(['cash', 'other']);
const BLOOD = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
const CATS = ['urgent', 'active', 'review', 'water', 'ramadan'];
const MANAGER = 'Mr. Abdelghader Ahmed';
const ICONS = ['heart', 'building', 'water', 'drop'];

/* ---------- helpers ---------- */
const iso = () => new Date().toISOString();
const uid = () => crypto.randomBytes(8).toString('hex');
const sum = (a, f) => a.reduce((s, x) => s + (Number(f(x)) || 0), 0);
const str = (v, max) => String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max);
const toInt = v => { const n = Math.trunc(Number(v)); return Number.isFinite(n) ? n : NaN; };
function fail(status, code) { const e = new Error(code); e.status = status; e.code = code; throw e; }
function writeAtomic(file, data, mode) {
  const tmp = file + '.' + process.pid + '.tmp';
  fs.writeFileSync(tmp, data, mode ? { mode } : undefined);
  fs.renameSync(tmp, file);
}
function scryptHash(pw) {
  const salt = crypto.randomBytes(16);
  return salt.toString('hex') + ':' + crypto.scryptSync(String(pw), salt, 32).toString('hex');
}
function scryptCheck(pw, stored) {
  try {
    const [s, h] = String(stored).split(':');
    const c = crypto.scryptSync(String(pw), Buffer.from(s, 'hex'), 32), b = Buffer.from(h, 'hex');
    return b.length === c.length && crypto.timingSafeEqual(b, c);
  } catch (e) { return false; }
}

/* ---------- config (secret + admin password) ---------- */
let cfg = null;
try { cfg = JSON.parse(fs.readFileSync(FILE_CFG, 'utf8')); } catch (e) { cfg = null; }
if (!cfg) {
  let pw = process.env.ADMIN_PASSWORD, generated = false;
  if (!pw) { pw = crypto.randomBytes(6).toString('base64url'); generated = true; }
  cfg = { secret: crypto.randomBytes(32).toString('hex'), adminHash: scryptHash(pw) };
  writeAtomic(FILE_CFG, JSON.stringify(cfg), 0o600);
  if (generated) console.log('\n  The control panel opens WITHOUT a password on this computer (localhost).\n  Online, a password is required: run  node server.js set-password "your-password"\n');
}
/* Three separate control panels, each with its own password:
   admin  = /admin   accounts, blood donors, activity, reports, settings
   manage = /manage  cases, charities, withdrawals + invoices
   topups = /topups  wallet top-ups only */
const ROLES = ['admin', 'manage', 'topups'];
const HASH_KEY = { admin: 'adminHash', manage: 'manageHash', topups: 'topupsHash' };
let cfgDirty = false;
[['manage', process.env.MANAGE_PASSWORD], ['topups', process.env.TOPUPS_PASSWORD]].forEach(([r, pw]) => {
  if (!cfg[HASH_KEY[r]]) { cfg[HASH_KEY[r]] = scryptHash(pw || crypto.randomBytes(12).toString('base64url')); cfgDirty = true; }
});
if (cfgDirty) writeAtomic(FILE_CFG, JSON.stringify(cfg), 0o600);
if (process.argv[2] === 'set-password') {
  const role = ROLES.includes(process.argv[3]) ? process.argv[3] : 'admin';
  const pw = ROLES.includes(process.argv[3]) ? process.argv[4] : process.argv[3];
  if (!pw || pw.length < 8) { console.error('Usage: node server.js set-password [admin|manage|topups] <at least 8 characters>'); process.exit(1); }
  cfg[HASH_KEY[role]] = scryptHash(pw);
  writeAtomic(FILE_CFG, JSON.stringify(cfg), 0o600);
  console.log('Password updated for panel: ' + role);
  process.exit(0);
}

/* ---------- database ---------- */
const EMPTY = () => ({
  settings: { whatsapp: '22230473900', bankily: '', masrvi: '', sedad: '', bloodAr: '', bloodEn: '' },
  cases: [], charities: [], donors: [], donations: [], accounts: [], ledger: [],
  requests: [], donor_requests: [], blood_searches: [], topups: [], activity: [], withdrawals: [], wdSeq: 0
});
let saveTimer = null;
let db = null;
try { db = Object.assign(EMPTY(), JSON.parse(fs.readFileSync(FILE_DB, 'utf8'))); } catch (e) { db = null; }
if (!db) { db = EMPTY(); seed(); flush(); }

function seed() {
  const ch = (id, ar, en, da, de, icon) => ({ id, name: { ar, en }, desc: { ar: da, en: de }, icon, verified: true });
  db.charities.push(ch('ataa', 'جمعية العطاء الخيرية', 'Al-Ataa Charity Association', 'جمعية خيرية تُعنى بدعم المحتاجين وإغاثة الأسر', 'A charity supporting people in need and relieving families', 'heart'));
  const d = new Date(Date.now() + 5 * 864e5).toISOString().slice(0, 10);
  db.cases.push({
    id: 'example-1', title: { ar: 'أحمد - سداد إيجار', en: 'Ahmed - rent payment' },
    location: { ar: 'نواكشوط - عرفات', en: 'Nouakchott - Arafat' },
    story: { ar: 'مثال: حالة تجريبية. احذفها أو عدّلها من لوحة التحكم.', en: 'Example: a sample case. Delete or edit it from the control panel.' },
    goal: 12000, baseRaised: 0, baseDonors: 0, deadline: d, category: 'urgent', image: '', verified: true, createdAt: iso()
  });
}
function save() { if (saveTimer) return; saveTimer = setTimeout(flush, 150); }
function flush() {
  if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; }
  writeAtomic(FILE_DB, JSON.stringify(db), 0o600);
}
['SIGINT', 'SIGTERM'].forEach(s => process.on(s, () => { try { flush(); } catch (e) {} process.exit(0); }));

/* Verification was removed: any leftover request becomes a normal account. */
function promote(rq) {
  if (!db.accounts.some(a => a.id === rq.id)) db.accounts.push({ id: rq.id, accountNo: rq.accountNo || rq.id, codeHash: rq.codeHash, status: 'verified', name: '', createdAt: rq.createdAt || iso(), verifiedAt: iso() });
  db.requests = db.requests.filter(x => x.id !== rq.id);
}
if (db.requests.length) { db.requests.slice().forEach(promote); flush(); }
if (!db.settings.whatsapp) { db.settings.whatsapp = '22230473900'; flush(); }
/* One charity only: remove the old sample associations, make sure Al-Ataa exists. */
(function () {
  const old = ['nour', 'amal', 'saqya', 'rahma'], before = db.charities.length;
  db.charities = db.charities.filter(c => !old.includes(c.id));
  if (!db.charities.some(c => c.id === 'ataa')) db.charities.unshift({ id: 'ataa', name: { ar: 'جمعية العطاء الخيرية', en: 'Al-Ataa Charity Association' }, desc: { ar: 'جمعية خيرية تُعنى بدعم المحتاجين وإغاثة الأسر', en: 'A charity supporting people in need and relieving families' }, icon: 'heart', verified: true });
  if (db.charities.length !== before || !db.charities.some(c => c.id === 'ataa')) flush();
})();

if (!db.withdrawals) { db.withdrawals = []; db.wdSeq = 0; flush(); }
const publicCase = c => { const o = Object.assign({}, c, { hasSecret: !!c.secretHash }); delete o.secretHash; return o; };
const caseFunds = c => { const p = prog(c), wd = sum(db.withdrawals.filter(w => w.caseId === c.id), w => w.amount); return { raised: p.raised, withdrawn: wd, available: p.raised - wd }; };
function logAct(acc, action, detail, by) {
  db.activity.unshift({ id: uid(), at: iso(), accountNo: acc || '', action, detail: str(detail, 200), by: by || 'user' });
  if (db.activity.length > 2000) db.activity.length = 2000;
}
const balance = acc => sum(db.ledger.filter(x => x.accountNo === acc), x => x.amount) - sum(db.donations.filter(x => x.accountNo === acc), x => x.amount);
function prog(c) {
  const raised = (Number(c.baseRaised) || 0) + sum(db.donations.filter(d => d.caseId === c.id), d => d.amount);
  const goal = Number(c.goal) || 0;
  const expired = c.deadline ? Date.now() > new Date(c.deadline + 'T23:59:59').getTime() : false;
  return { raised, goal, left: Math.max(0, goal - raised), closed: expired || (goal > 0 && raised >= goal) };
}

/* ---------- sessions ---------- */
const sign = p => {
  const body = Buffer.from(JSON.stringify(p)).toString('base64url');
  return body + '.' + crypto.createHmac('sha256', cfg.secret).update(body).digest('base64url');
};
function unsign(t) {
  if (!t) return null;
  const [body, mac] = String(t).split('.');
  if (!body || !mac) return null;
  const exp = crypto.createHmac('sha256', cfg.secret).update(body).digest('base64url');
  const a = Buffer.from(mac), b = Buffer.from(exp);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try { const p = JSON.parse(Buffer.from(body, 'base64url').toString()); return p.e > Date.now() ? p : null; } catch (e) { return null; }
}
function cookies(req) {
  const o = {};
  String(req.headers.cookie || '').split(';').forEach(c => {
    const i = c.indexOf('=');
    if (i > 0) { try { o[c.slice(0, i).trim()] = decodeURIComponent(c.slice(i + 1).trim()); } catch (e) {} }
  });
  return o;
}
function setCk(req, res, name, value, maxAge) {
  const secure = process.env.COOKIE_SECURE === '1' || req.headers['x-forwarded-proto'] === 'https';
  (res.cookies = res.cookies || []).push(name + '=' + encodeURIComponent(value) + '; Path=/; HttpOnly; SameSite=Strict; Max-Age=' + maxAge + (secure ? '; Secure' : ''));
}
/* Same-computer visits (no proxy headers, localhost host) open the control panel without a password. */
function isLocal(req) {
  const ra = req.socket.remoteAddress;
  const h = req.headers;
  return (ra === '127.0.0.1' || ra === '::1' || ra === '::ffff:127.0.0.1') &&
    !h['x-forwarded-for'] && !h['x-real-ip'] && !h.forwarded && !h['x-forwarded-host'] &&
    /^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/.test(String(h.host || ''));
}
function auth(req) {
  const c = cookies(req), out = { user: null, admin: false, local: false, roles: { admin: false, manage: false, topups: false } };
  if (process.env.ADMIN_REQUIRE_PASSWORD !== '1' && isLocal(req)) { ROLES.forEach(r => { out.roles[r] = true; }); out.local = true; }
  ROLES.forEach(r => {
    const a = unsign(c['dek_' + r]);
    if (a && a.r === r && a.v === cfg[HASH_KEY[r]].slice(-8)) out.roles[r] = true;
  });
  out.admin = out.roles.admin;
  const u = unsign(c.dek_user);
  if (u && u.r === 'user') {
    let acc = db.accounts.find(x => x.id === u.a);
    const rq = db.requests.find(x => x.id === u.a);
    if (!acc && rq) { promote(rq); acc = db.accounts.find(x => x.id === u.a); save(); }
    const rec = acc || rq;
    if (rec && rec.codeHash.slice(-8) === u.v) out.user = { acc: u.a, status: acc ? acc.status : (rq.status === 'rejected' ? 'rejected' : 'pending') };
  }
  return out;
}
const hits = new Map();
function limited(key, max, win) {
  const n = Date.now();
  const a = (hits.get(key) || []).filter(t => n - t < win);
  if (a.length >= max) { hits.set(key, a); return true; }
  a.push(n); hits.set(key, a); return false;
}
setInterval(() => { const n = Date.now(); for (const [k, v] of hits) { if (!v.some(t => n - t < 36e5)) hits.delete(k); } }, 6e5).unref();
/* Account lockout: 5 wrong codes in a row lock the account number for 15 minutes. */
const fails = new Map();
const lockedOut = acc => { const f = fails.get(acc); return !!f && f.until > Date.now(); };
function failed(acc) { const f = fails.get(acc) || { n: 0, until: 0 }; f.n++; if (f.n >= 5) { f.until = Date.now() + 15 * 6e4; f.n = 0; } fails.set(acc, f); }
setInterval(() => { const n = Date.now(); for (const [k, v] of fails) if (v.until < n && !v.n) fails.delete(k); }, 6e5).unref();
const clientIp = req => process.env.TRUST_PROXY === '1'
  ? (String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress)
  : req.socket.remoteAddress;

/* ---------- images ---------- */
function saveImage(dataUrl, dir) {
  const s = String(dataUrl || '');
  const comma = s.indexOf(',');
  const head = s.slice(0, comma);
  const m = /^data:image\/(jpeg|png|webp);base64$/.exec(head);
  if (comma < 0 || !m) fail(400, 'err_image');
  const buf = Buffer.from(s.slice(comma + 1), 'base64');
  if (buf.length < 100 || buf.length > 2000000) fail(400, 'err_image');
  const t = m[1];
  const ok = (t === 'jpeg' && buf[0] === 0xff && buf[1] === 0xd8) ||
    (t === 'png' && buf.slice(0, 4).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47]))) ||
    (t === 'webp' && buf.slice(0, 4).toString() === 'RIFF' && buf.slice(8, 12).toString() === 'WEBP');
  if (!ok) fail(400, 'err_image');
  const name = crypto.randomBytes(8).toString('hex') + '.' + (t === 'jpeg' ? 'jpg' : t);
  fs.writeFileSync(path.join(dir, name), buf);
  return name;
}
const PUB_IMG = /^\/uploads\/[a-f0-9]{16}\.(jpg|png|webp)$/;
const PRIV_IMG = /^\/api\/receipt\/[a-f0-9]{16}\.(jpg|png|webp)$/;

/* ---------- state per role ---------- */
const clean = d => { const o = Object.assign({}, d); delete o.codeHash; return o; };
function maskAcc(acc) { return 'x' + crypto.createHmac('sha256', cfg.secret).update('acc:' + acc).digest('hex').slice(0, 8); }
function buildState(a) {
  const R = a.roles, anyPanel = R.admin || R.manage || R.topups;
  const out = { me: { user: a.user, admin: a.admin, roles: R, local: a.local }, settings: db.settings };
  if (a.user) {
    const acc = db.accounts.find(x => x.id === a.user.acc), rq = db.requests.find(x => x.id === a.user.acc);
    const dr = db.donor_requests.find(x => x.id === a.user.acc);
    out.accountDoc = acc ? clean(acc) : null;
    out.requestDoc = rq ? clean(rq) : null;
    out.myDonorReq = dr || null;
    out.myDonor = db.donors.some(d => d.accountNo === a.user.acc);
    out.myBloodSearches = db.blood_searches.filter(x => x.accountNo === a.user.acc).slice(-10).reverse();
  }
  const verified = anyPanel || (a.user && (a.user.status === 'verified' || a.user.status === 'pending'));
  if (verified) {
    out.cases = db.cases.map(publicCase);
    out.charities = db.charities;
    if (R.admin || R.manage) {
      out.donors = R.admin ? db.donors : [];
      out.donations = db.donations;
    } else if (R.topups) {
      out.donors = []; out.donations = [];
    } else {
      out.donors = [];
      out.donations = db.donations.map(d => ({ id: d.id, caseId: d.caseId, charityId: d.charityId, amount: d.amount, at: d.at, accountNo: d.accountNo === a.user.acc ? d.accountNo : maskAcc(d.accountNo) }));
    }
    if (a.user) {
      out.myLedger = db.ledger.filter(x => x.accountNo === a.user.acc).map(x => ({ id: x.id, accountNo: x.accountNo, amount: x.amount, method: x.method, source: x.source, topupId: x.topupId, at: x.at }));
      out.myTopups = db.topups.filter(x => x.accountNo === a.user.acc).map(x => ({ id: x.id, accountNo: x.accountNo, method: x.method, amount: x.amount, status: x.status, at: x.at }));
    }
  }
  const recMap = t => { const o = Object.assign({}, t, { receipt: t.receiptFile ? '/api/receipt/' + t.receiptFile : '' }); delete o.receiptFile; return o; };
  if (R.admin) {
    out.accounts = db.accounts.map(clean);
    out.ledger = db.ledger;
    out.requests = db.requests.map(clean);
    out.donor_requests = db.donor_requests;
    out.blood_searches = db.blood_searches;
    out.withdrawals = db.withdrawals;
    out.topups = db.topups.map(recMap);
    out.activity = db.activity.slice(0, 400);
  } else {
    if (R.manage) out.withdrawals = db.withdrawals;
    if (R.topups) {
      out.accounts = db.accounts.map(x => ({ id: x.id, accountNo: x.accountNo, name: x.name, status: x.status }));
      out.ledger = db.ledger;
      out.topups = db.topups.map(recMap);
    }
  }
  return out;
}

/* ---------- actions ---------- */
/* Money actions need a verified account. Browsing and profile work in the free trial (pending). */
function needUser(ctx) {
  if (!ctx.user) fail(401, 'err_wrong');
  if (ctx.user.status === 'pending') fail(403, 'err_unverified');
  if (ctx.user.status !== 'verified') fail(403, 'err_generic');
  return ctx.user;
}
function needAny(ctx) {
  if (!ctx.user) fail(401, 'err_wrong');
  if (ctx.user.status !== 'verified' && ctx.user.status !== 'pending') fail(403, 'err_generic');
  return ctx.user;
}
const normPhone = v => String(v || '').replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/\D/g, '').replace(/^222/, '');
const A = {
  /* user */
  donate(ctx, b) {
    const me = needUser(ctx);
    if (b.charityId) {
      const ch = db.charities.find(x => x.id === b.charityId);
      if (!ch) fail(404, 'no_ch');
      const amt = toInt(b.amount);
      if (!(amt > 0) || amt > 1e9) fail(400, 'err_amount');
      if (amt > balance(me.acc)) fail(400, 'err_insufficient');
      db.donations.push({ id: uid(), accountNo: me.acc, charityId: ch.id, amount: amt, at: iso() });
      logAct(me.acc, 'donation', amt + ' MRU · ' + (ch.name.ar || ch.name.en));
      save(); return { ok: true };
    }
    const c = db.cases.find(x => x.id === b.caseId);
    if (!c) fail(404, 'no_cases');
    const amt = toInt(b.amount);
    if (!(amt > 0) || amt > 1e9) fail(400, 'err_amount');
    const p = prog(c);
    if (c.category === 'review' || p.closed) fail(400, 'closed_note');
    if (amt > p.left) fail(400, 'err_over');
    if (amt > balance(me.acc)) fail(400, 'err_insufficient');
    db.donations.push({ id: uid(), accountNo: me.acc, caseId: c.id, amount: amt, at: iso() });
    logAct(me.acc, 'donation', amt + ' MRU · ' + (c.title.ar || c.title.en));
    save(); return { ok: true };
  },
  topup(ctx, b) {
    const me = needUser(ctx);
    const amt = toInt(b.amount), ref = str(b.ref, 40);
    if (!METHODS.includes(b.method)) fail(400, 'err_generic');
    if (!(amt > 0) || amt > 1e7) fail(400, 'err_amount');
    if (ref.length < 3) fail(400, 'err_ref');
    if (db.topups.filter(t => t.accountNo === me.acc && t.status === 'pending').length >= 20) fail(429, 'err_rate');
    if (!b.receipt) fail(400, 'err_receipt');
    if (db.topups.some(t => t.method === b.method && t.ref.toLowerCase() === ref.toLowerCase() && t.status !== 'rejected')) fail(409, 'err_dup_ref');
    if (db.topups.filter(t => t.accountNo === me.acc && Date.now() - Date.parse(t.at) < 864e5).length >= 30) fail(429, 'err_rate');
    const receiptFile = saveImage(b.receipt, UP_PRIV);
    db.topups.push({ id: uid(), accountNo: me.acc, method: b.method, amount: amt, ref, receiptFile, status: 'pending', at: iso() });
    logAct(me.acc, 'topup_request', amt + ' MRU · ' + b.method);
    save(); return { ok: true };
  },
  profile_save(ctx, b) {
    const me = needAny(ctx), a = db.accounts.find(x => x.id === me.acc);
    if (!a) fail(404, 'err_noacc');
    a.name = str(b.name, 40);
    if ((b.photo || b.removePhoto) && limited('ph:' + me.acc, 10, 36e5)) fail(429, 'err_rate');
    const old = a.photo;
    if (b.photo) a.photo = '/uploads/' + saveImage(b.photo, UP_PUB);
    else if (b.removePhoto) a.photo = '';
    if (old && old !== a.photo && PUB_IMG.test(old) && !db.cases.some(c => c.image === old)) fs.unlink(path.join(UP_PUB, path.basename(old)), () => {});
    logAct(me.acc, 'profile_saved', ''); save(); return { ok: true };
  },
  donor_request(ctx, b) {
    const me = needAny(ctx);
    const name = str(b.name, 60), phone = normPhone(b.phone);
    if (!name) fail(400, 'err_name');
    if (!/^\d{8}$/.test(phone)) fail(400, 'err_phone');
    const type = BLOOD.includes(b.bloodType) ? b.bloodType : 'O+';
    db.donor_requests = db.donor_requests.filter(x => x.id !== me.acc);
    db.donor_requests.push({ id: me.acc, accountNo: me.acc, name, bloodType: type, city: str(b.city, 40), phone, status: 'pending', at: iso() });
    logAct(me.acc, 'donor_request', type);
    save(); return { ok: true };
  },
  blood_search(ctx, b) {
    const me = needAny(ctx);
    const hospital = str(b.hospital, 80), w = toInt(b.wilaya);
    if (!hospital) fail(400, 'err_hospital');
    if (!BLOOD.includes(b.bloodType)) fail(400, 'err_generic');
    if (!(w >= 0 && w < 15)) fail(400, 'err_generic');
    if (limited('bs:' + me.acc, 5, 36e5)) fail(429, 'err_rate');
    const id = uid();
    db.blood_searches.push({ id, accountNo: me.acc, hospital, bloodType: b.bloodType, wilaya: w, status: 'open', at: iso() });
    if (db.blood_searches.length > 2000) db.blood_searches.splice(0, db.blood_searches.length - 2000);
    logAct(me.acc, 'blood_search', b.bloodType + ' · ' + hospital);
    save(); return { ok: true };
  },
  blood_search_status(ctx, b) {
    const r = db.blood_searches.find(x => x.id === str(b.id, 40));
    if (!r) fail(404, 'err_generic');
    r.status = ['open', 'found', 'closed'].includes(b.status) ? b.status : 'open'; r.updatedAt = iso();
    logAct(r.accountNo, 'blood_search_' + r.status, r.bloodType, 'admin'); save(); return { ok: true };
  },
  /* admin: accounts */
  account_create(ctx, b) {
    const norm = v => String(v == null ? '' : v).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
    let phone = norm(b.phone).replace(/\D/g, '');
    if (/^222\d{8}$/.test(phone)) phone = phone.slice(3);
    if (!/^\d{6,15}$/.test(phone)) fail(400, 'err_phone');
    const first = str(b.first, 30), last = str(b.last, 30), pw = norm(b.password);
    if (!first) fail(400, 'err_first');
    if (pw.length < 6 || pw.length > 64) fail(400, 'err_pwlen');
    if (db.accounts.some(x => x.id === phone)) fail(409, 'err_exists');
    if (db.ledger.some(x => x.accountNo === phone) || db.donations.some(x => x.accountNo === phone) || db.topups.some(x => x.accountNo === phone)) fail(403, 'err_taken');
    db.accounts.push({ id: phone, accountNo: phone, codeHash: scryptHash(pw), status: 'verified', first, last, name: (first + ' ' + last).trim(), phone, nid: str(norm(b.nid), 20), abroad: phone.length !== 8, createdAt: iso(), verifiedAt: iso() });
    logAct(phone, 'account_created', '', 'admin'); save(); return { ok: true };
  },
  account_approve(ctx, b) {
    const a = db.accounts.find(x => x.id === str(b.acc, 20));
    if (!a) fail(404, 'err_noacc');
    a.status = 'verified'; a.verifiedAt = iso();
    logAct(a.id, 'account_verified', '#' + (a.ref || ''), 'admin'); save(); return { ok: true };
  },
  account_reject(ctx, b) {
    const a = db.accounts.find(x => x.id === str(b.acc, 20));
    if (!a) fail(404, 'err_noacc');
    a.status = 'rejected';
    logAct(a.id, 'account_rejected', '', 'admin'); save(); return { ok: true };
  },
  account_suspend(ctx, b) {
    const a = db.accounts.find(x => x.id === str(b.acc, 20));
    if (!a) fail(404, 'err_noacc');
    a.status = a.status === 'suspended' ? (a.verifiedAt ? 'verified' : 'pending') : 'suspended';
    logAct(a.id, a.status === 'suspended' ? 'account_suspended' : 'account_reactivated', '', 'admin'); save(); return { ok: true };
  },
  account_delete(ctx, b) {
    const acc = str(b.acc, 20);
    db.accounts = db.accounts.filter(x => x.id !== acc);
    db.requests = db.requests.filter(x => x.id !== acc);
    db.donor_requests = db.donor_requests.filter(x => x.id !== acc);
    logAct(acc, 'account_deleted', '', 'admin'); save(); return { ok: true };
  },
  account_edit(ctx, b) {
    const a = db.accounts.find(x => x.id === str(b.acc, 20));
    if (!a) fail(404, 'err_noacc');
    a.name = str(b.name, 60); save(); return { ok: true };
  },
  /* admin: money */
  topup_approve(ctx, b) {
    const t = db.topups.find(x => x.id === b.id);
    if (!t || t.status !== 'pending') fail(404, 'err_generic');
    if (!db.accounts.some(a => a.id === t.accountNo)) fail(400, 'err_noacc');
    const amt = toInt(b.amount);
    if (!(amt > 0) || amt > 1e7) fail(400, 'err_amount');
    const l = { id: uid(), accountNo: t.accountNo, amount: amt, method: t.method, ref: t.ref, source: 'topup', topupId: t.id, at: iso() };
    db.ledger.push(l);
    t.status = 'approved'; t.amountApproved = amt; t.ledgerId = l.id; t.reviewedAt = iso();
    logAct(t.accountNo, 'topup_approved', amt + ' MRU', 'admin'); save(); return { ok: true };
  },
  topup_reject(ctx, b) {
    const t = db.topups.find(x => x.id === b.id);
    if (!t || t.status !== 'pending') fail(404, 'err_generic');
    t.status = 'rejected'; t.reviewedAt = iso();
    logAct(t.accountNo, 'topup_rejected', '', 'admin'); save(); return { ok: true };
  },
  tx_add(ctx, b) {
    const acc = str(b.acc, 20), amt = toInt(b.amount);
    if (!db.accounts.some(a => a.id === acc)) fail(400, 'err_noacc');
    if (!amt || Math.abs(amt) > 1e7) fail(400, 'err_amount');
    const image = String(b.image || '');
    if (image && !PRIV_IMG.test(image)) fail(400, 'err_image');
    db.ledger.push({ id: uid(), accountNo: acc, amount: amt, method: TX_METHODS.includes(b.method) ? b.method : 'other', ref: str(b.ref, 40), note: str(b.note, 200), image, source: 'admin', at: iso() });
    logAct(acc, 'tx_upload', amt + ' MRU', 'admin'); save(); return { ok: true };
  },
  /* admin: content */
  case_save(ctx, b) {
    const d = b.data || {};
    const titleAr = str(d.title_ar, 120), titleEn = str(d.title_en, 120);
    if (!titleAr && !titleEn) fail(400, 'err_title');
    const goal = toInt(d.goal);
    if (!(goal > 0) || goal > 1e9) fail(400, 'err_goal');
    const base = toInt(d.baseRaised) || 0, bd = toInt(d.baseDonors) || 0;
    if (base < 0 || base > 1e9 || bd < 0 || bd > 1e6) fail(400, 'err_amount');
    const deadline = /^\d{4}-\d{2}-\d{2}$/.test(String(d.deadline || '')) ? d.deadline : '';
    const image = String(d.image || '');
    if (image && !PUB_IMG.test(image)) fail(400, 'err_image');
    const doc = {
      title: { ar: titleAr, en: titleEn }, location: { ar: str(d.loc_ar, 80), en: str(d.loc_en, 80) },
      story: { ar: str(d.story_ar, 3000), en: str(d.story_en, 3000) }, goal, baseRaised: base, baseDonors: bd, deadline,
      category: CATS.includes(d.category) ? d.category : 'active', image, verified: true
    };
    const cur = b.id ? db.cases.find(x => x.id === b.id) : null;
    const secret = String(d.secret == null ? '' : d.secret).replace(/[٠-٩]/g, x => '٠١٢٣٤٥٦٧٨٩'.indexOf(x)).trim();
    if (secret && (secret.length < 4 || secret.length > 12)) fail(400, 'err_secret_len');
    if (!cur && !secret) fail(400, 'err_secret_len');
    if (secret) doc.secretHash = scryptHash(secret);
    if (cur) Object.assign(cur, doc);
    else db.cases.push(Object.assign({ id: uid(), createdAt: iso() }, doc));
    logAct('', 'case_saved', titleAr || titleEn, 'admin'); save(); return { ok: true };
  },
  withdraw(ctx, b) {
    const c = db.cases.find(x => x.id === b.caseId);
    if (!c) fail(404, 'no_cases');
    if (!c.secretHash) fail(400, 'err_nosecret');
    const key = 'cs:' + c.id;
    if (lockedOut(key)) fail(429, 'err_locked');
    if (!scryptCheck(String(b.secret == null ? '' : b.secret).replace(/[٠-٩]/g, x => '٠١٢٣٤٥٦٧٨٩'.indexOf(x)).trim().slice(0, 40), c.secretHash)) { failed(key); fail(401, 'err_secret'); }
    fails.delete(key);
    const amt = toInt(b.amount), payee = str(b.payee, 80), purpose = str(b.purpose, 200);
    if (!(amt > 0) || amt > 1e9) fail(400, 'err_amount');
    if (!payee) fail(400, 'err_name');
    if (amt > caseFunds(c).available) fail(400, 'err_wd_over');
    db.wdSeq = (db.wdSeq || 0) + 1;
    const w = { id: uid(), no: 'WD-' + String(db.wdSeq).padStart(5, '0'), caseId: c.id, caseTitle: { ar: c.title.ar, en: c.title.en }, amount: amt, payee, purpose, signedBy: MANAGER, at: iso() };
    db.withdrawals.push(w);
    logAct('', 'withdraw', w.no + ' · ' + amt + ' MRU · ' + (c.title.ar || c.title.en), 'admin'); save();
    return { ok: true, id: w.id };
  },
  donor_approve(ctx, b) {
    const acc = str(b.acc || b.id, 20), r = db.donor_requests.find(x => x.id === acc);
    if (!r) fail(404, 'err_generic');
    db.donors = db.donors.filter(x => x.id !== acc);
    db.donors.push({ id: acc, accountNo: r.accountNo, name: r.name, bloodType: r.bloodType, city: r.city || '', phone: r.phone, verifiedAt: iso() });
    r.status = 'approved'; r.reviewedAt = iso();
    logAct(r.accountNo, 'donor_approved', r.bloodType, 'admin'); save(); return { ok: true };
  },
  donor_reject(ctx, b) {
    const r = db.donor_requests.find(x => x.id === str(b.acc || b.id, 20));
    if (!r) fail(404, 'err_generic');
    r.status = 'rejected'; r.reviewedAt = iso();
    logAct(r.accountNo, 'donor_rejected', '', 'admin'); save(); return { ok: true };
  },
  donor_save(ctx, b) {
    const name = str(b.name, 60), phone = normPhone(b.phone);
    if (!name) fail(400, 'err_name');
    if (!/^\d{8}$/.test(phone)) fail(400, 'err_phone');
    const data = { name, bloodType: BLOOD.includes(b.bloodType) ? b.bloodType : 'O+', city: str(b.city, 40), phone };
    const cur = b.id ? db.donors.find(x => x.id === b.id) : null;
    if (cur) Object.assign(cur, data);
    else db.donors.push(Object.assign({ id: uid(), accountNo: '', verifiedAt: iso() }, data));
    save(); return { ok: true };
  },
  charity_save(ctx, b) {
    const na = str(b.name_ar, 100), ne = str(b.name_en, 100);
    if (!na && !ne) fail(400, 'err_name');
    const doc = { name: { ar: na, en: ne }, desc: { ar: str(b.desc_ar, 300), en: str(b.desc_en, 300) }, icon: ICONS.includes(b.icon) ? b.icon : 'heart', verified: true };
    const cur = b.id ? db.charities.find(x => x.id === b.id) : null;
    if (cur) Object.assign(cur, doc); else db.charities.push(Object.assign({ id: uid() }, doc));
    save(); return { ok: true };
  },
  delete_doc(ctx, b) {
    const COLS = { ledger: 'ledger', cases: 'cases', donors: 'donors', charities: 'charities' };
    if (typeof b.col !== 'string' || !Object.prototype.hasOwnProperty.call(COLS, b.col)) fail(400, 'err_generic');
    const col = COLS[b.col];
    const need = { ledger: 'topups', cases: 'manage', charities: 'manage', donors: 'admin' }[col];
    if (!ctx.roles[need]) fail(403, 'err_generic');
    db[col] = db[col].filter(x => x.id !== b.id);
    logAct('', 'item_deleted', b.col, 'admin'); save(); return { ok: true };
  },
  settings_save(ctx, b) {
    const num = v => String(v || '').replace(/[^\d+ ]/g, '').trim().slice(0, 20);
    const wa = String(b.whatsapp || '').replace(/\D/g, '');
    db.settings = { whatsapp: wa.length >= 8 && wa.length <= 15 ? wa : '22230473900', bankily: num(b.bankily), masrvi: num(b.masrvi), sedad: num(b.sedad), bloodAr: str(b.bloodAr, 400), bloodEn: str(b.bloodEn, 400) };
    logAct('', 'settings_saved', '', 'admin'); save(); return { ok: true };
  },
  prune() { db.activity.length = Math.min(db.activity.length, 300); save(); return { ok: true }; }
};
const ACTION_ROLE = {
  account_approve: 'admin', account_reject: 'admin', account_suspend: 'admin', account_delete: 'admin', account_edit: 'admin', account_create: 'admin',
  donor_approve: 'admin', donor_reject: 'admin', donor_save: 'admin', blood_search_status: 'admin', settings_save: 'admin', prune: 'admin',
  case_save: 'manage', charity_save: 'manage', withdraw: 'manage',
  topup_approve: 'topups', topup_reject: 'topups', tx_add: 'topups'
};
const USER_ACTIONS = new Set(['donate', 'topup', 'donor_request', 'blood_search', 'profile_save']);

/* ---------- http ---------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon', '.json': 'application/json', '.webmanifest': 'application/manifest+json' };
function baseHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
}
function json(res, code, obj) {
  res.setHeader('Strict-Transport-Security', 'max-age=31536000');
  if (res.cookies && res.cookies.length) res.setHeader('Set-Cookie', res.cookies);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let n = 0; const chunks = [];
    req.on('data', c => { n += c.length; if (n > 3.5e6) { reject(Object.assign(new Error('big'), { status: 413, code: 'err_image' })); req.destroy(); } else chunks.push(c); });
    req.on('end', () => {
      try { const v = chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}; if (!v || typeof v !== 'object' || Array.isArray(v)) throw new Error('shape'); resolve(v); }
      catch (e) { reject(Object.assign(new Error('json'), { status: 400, code: 'err_generic' })); }
    });
    req.on('error', reject);
  });
}
function serveFile(res, file, cache, hdrs) {
  fs.readFile(file, (e, buf) => {
    if (e) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    res.writeHead(200, Object.assign({ 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Cache-Control': cache }, hdrs || {}));
    res.end(buf);
  });
}

async function api(req, res, p) {
  const ctx = auth(req);
  if (req.method === 'GET') {
    if (p === '/api/state') return json(res, 200, buildState(ctx));
    let m = /^\/api\/donor-phone\/([A-Za-z0-9_-]{1,40})$/.exec(p);
    if (m) {
      if (!ctx.roles.admin) fail(403, 'err_generic');
      const d = db.donors.find(x => x.id === m[1]);
      if (!d) fail(404, 'err_generic');
      return json(res, 200, { phone: d.phone });
    }
    m = /^\/api\/receipt\/([a-f0-9]{16}\.(?:jpg|png|webp))$/.exec(p);
    if (m) {
      if (!ctx.roles.admin && !ctx.roles.topups) fail(403, 'err_generic');
      return serveFile(res, path.join(UP_PRIV, m[1]), 'private, max-age=3600');
    }
    if (p === '/api/health') return json(res, 200, { ok: true });
    fail(404, 'err_generic');
  }
  if (req.method !== 'POST') fail(405, 'err_generic');
  if (!String(req.headers['content-type'] || '').includes('application/json')) fail(415, 'err_generic');
  if (req.headers['sec-fetch-site'] === 'cross-site') fail(403, 'err_generic');
  const origin = req.headers.origin;
  if (origin) { try { if (new URL(origin).host !== req.headers.host) fail(403, 'err_generic'); } catch (e) { fail(403, 'err_generic'); } }
  const b = await readBody(req);
  const ip = clientIp(req);

  if (p === '/api/login') {
    let acc = str(b.acc, 24).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[\s+]/g, '');
    if (/^222\d{8}$/.test(acc)) acc = acc.slice(3);
    const code = String(b.code == null ? '' : b.code).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
    if (!/^[A-Za-z0-9-]{4,20}$/.test(acc)) fail(400, 'err_acc');
    if (code.length < 4 || code.length > 64) fail(400, 'err_code');
    if (limited('lg:' + ip, 15, 6e5) || limited('la:' + acc, 12, 6e5) || limited('lgall', 240, 6e4)) fail(429, 'err_rate');
    if (lockedOut(acc)) fail(429, 'err_locked');
    const month = 14 * 864e5;
    const grant = hash => { setCk(req, res, 'dek_user', sign({ r: 'user', a: acc, v: hash.slice(-8), e: Date.now() + month }), month / 1000); };
    const a = db.accounts.find(x => x.id === acc);
    if (a) {
      if (!scryptCheck(code, a.codeHash)) { failed(acc); if (limited('lf:' + ip, 10, 6e5)) fail(429, 'err_rate'); fail(401, 'err_wrong'); }
      fails.delete(acc);
      if (a.status === 'suspended') fail(403, 'err_suspended');
      if (a.status === 'rejected') fail(403, 'err_rejected');
      grant(a.codeHash); logAct(acc, 'login', ''); save();
      return json(res, 200, { ok: true, status: a.status });
    }
    failed(acc); limited('lf:' + ip, 10, 6e5);
    fail(401, 'err_wrong');
  }
  if (p === '/api/register') {
    if (limited('rg:' + ip, 8, 36e5) || limited('rgall', 120, 36e5)) fail(429, 'err_rate');
    const norm = v => String(v == null ? '' : v).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
    const first = str(b.first, 30), last = str(b.last, 30), phone = normPhone(norm(b.phone)), nid = norm(b.nid).replace(/\s/g, '');
    const pw = norm(b.password), pw2 = norm(b.password2);
    if (first.length < 2 || last.length < 2) fail(400, 'err_first');
    if (!/^\d{8}$/.test(phone)) fail(400, 'err_phone');
    if (!/^\d{8,14}$/.test(nid)) fail(400, 'err_nid');
    if (pw.length < 6 || pw.length > 64) fail(400, 'err_pwlen');
    if (pw !== pw2) fail(400, 'err_pwmatch');
    if (db.accounts.some(x => x.id === phone) || db.requests.some(x => x.id === phone)) fail(409, 'err_exists');
    if (db.accounts.some(x => x.nid && x.nid === nid)) fail(409, 'err_exists_nid');
    if (db.ledger.some(x => x.accountNo === phone) || db.donations.some(x => x.accountNo === phone) || db.topups.some(x => x.accountNo === phone)) fail(403, 'err_taken');
    const ref = crypto.randomBytes(3).toString('hex').toUpperCase(), hash = scryptHash(pw);
    db.accounts.push({ id: phone, accountNo: phone, codeHash: hash, status: 'pending', first, last, name: first + ' ' + last, phone, nid, ref, createdAt: iso() });
    setCk(req, res, 'dek_user', sign({ r: 'user', a: phone, v: hash.slice(-8), e: Date.now() + 14 * 864e5 }), 14 * 864e2);
    logAct(phone, 'register', '#' + ref); save();
    return json(res, 200, { ok: true, ref });
  }
  if (p === '/api/logout') { setCk(req, res, 'dek_user', '', 0); return json(res, 200, { ok: true }); }
  if (p === '/api/admin/login') {
    const role = ROLES.includes(b.role) ? b.role : 'admin';
    if (limited('ad:' + ip, 8, 6e5) || limited('adall', 60, 6e5)) fail(429, 'err_rate');
    if (!scryptCheck(String(b.password || '').slice(0, 200), cfg[HASH_KEY[role]])) fail(401, 'err_pw_wrong');
    setCk(req, res, 'dek_' + role, sign({ r: role, v: cfg[HASH_KEY[role]].slice(-8), e: Date.now() + 12 * 36e5 }), 12 * 3600);
    return json(res, 200, { ok: true });
  }
  if (p === '/api/admin/logout') { const role = ROLES.includes(b.role) ? b.role : 'admin'; setCk(req, res, 'dek_' + role, '', 0); return json(res, 200, { ok: true }); }

  if (p === '/api/admin/password') {
    const role = ROLES.includes(b.role) ? b.role : 'admin';
    if (!ctx.roles[role]) fail(403, 'err_generic');
    if (limited('pw:' + ip, 8, 6e5)) fail(429, 'err_rate');
    if (!ctx.local && !scryptCheck(String(b.current || '').slice(0, 200), cfg[HASH_KEY[role]])) fail(401, 'err_pw_wrong');
    const next = String(b.next || '');
    if (next.length < 8 || next.length > 200) fail(400, 'err_pw');
    cfg[HASH_KEY[role]] = scryptHash(next);
    writeAtomic(FILE_CFG, JSON.stringify(cfg), 0o600);
    logAct('', 'password_changed', role, 'admin'); save();
    setCk(req, res, 'dek_' + role, sign({ r: role, v: cfg[HASH_KEY[role]].slice(-8), e: Date.now() + 12 * 36e5 }), 12 * 3600);
    return json(res, 200, { ok: true });
  }
  if (p === '/api/upload') {
    const priv = !!b.private;
    if (!(priv ? ctx.roles.topups : ctx.roles.manage)) fail(403, 'err_generic');
    const name = saveImage(b.dataUrl, priv ? UP_PRIV : UP_PUB);
    return json(res, 200, { ok: true, url: (priv ? '/api/receipt/' : '/uploads/') + name });
  }
  if (p === '/api/action') {
    const fn = A[b.type];
    if (!fn || !Object.prototype.hasOwnProperty.call(A, b.type)) fail(400, 'err_generic');
    if (USER_ACTIONS.has(b.type)) { if (limited('ac:' + (ctx.user ? ctx.user.acc : ip), 60, 6e4)) fail(429, 'err_rate'); }
    else { const need = ACTION_ROLE[b.type]; if (!need || !ctx.roles[need]) fail(403, 'err_generic'); }
    return json(res, 200, fn(ctx, b));
  }
  fail(404, 'err_generic');
}

const server = http.createServer((req, res) => {
  baseHeaders(res);
  let p;
  try { p = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch (e) { res.writeHead(400); return res.end(); }
  const done = e => {
    if (e && e.status) return json(res, e.status, { error: e.code || 'err_generic' });
    console.error(e); json(res, 500, { error: 'err_generic' });
  };
  try {
    if (p.startsWith('/api/')) { api(req, res, p).catch(done); return; }
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
    const mu = /^\/uploads\/([a-f0-9]{16}\.(?:jpg|png|webp))$/.exec(p);
    if (mu) return serveFile(res, path.join(UP_PUB, mu[1]), 'public, max-age=604800, immutable');
    const page = (p === '/admin' || p === '/admin/' || p === '/admin.html') ? 'admin.html' : (p === '/manage' || p === '/manage/' || p === '/manage.html') ? 'manage.html' : (p === '/topups' || p === '/topups/' || p === '/topups.html') ? 'topups.html' : (p === '/' || p === '/index.html') ? 'index.html' : '';
    if (page) {
      const pf = path.join(PUB, page);
      if (!fs.existsSync(pf)) {
        res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
        return res.end(page + ' not found. Keep index.html, admin.html, app.js and styles.css next to server.js.\nلم يوجد ' + page + '. ضع الملفات index.html و admin.html و app.js و styles.css بجانب server.js.');
      }
      return serveFile(res, pf, 'no-cache');
    }
    if (FLAT && !FLAT_FILES.has(p.slice(1))) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    const f = path.normalize(path.join(PUB, p));
    if (!f.startsWith(PUB + path.sep)) { res.writeHead(403); return res.end(); }
    serveFile(res, f, 'no-cache');
  } catch (e) { done(e); }
});
server.headersTimeout = 15000; server.requestTimeout = 30000; server.keepAliveTimeout = 5000; server.maxHeadersCount = 60;
server.listen(PORT, HOST, () => {
  console.log('Dar El Kheir running: http://localhost:' + PORT + '\n  Panel 1 (accounts, donors, reports, settings): /admin\n  Panel 2 (cases, charities, withdrawals):       /manage\n  Panel 3 (wallet top-ups only):                 /topups');
});
